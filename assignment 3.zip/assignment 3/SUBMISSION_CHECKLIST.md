# Submission checklist

- [ ] Add register number to README.md and REPORT.md
- [ ] Create repository: `CSA08-<RegisterNumber>-Assignment3`
- [ ] Add the GitHub URL to REPORT.md and the assignment cover page
- [ ] Run all seven programs on your own computer
- [ ] Capture screenshots showing code execution and outputs
- [ ] Commit each Task folder progressively (at least one commit per task)
- [ ] Share the repository with course faculty
- [ ] Upload the report and submit the GitHub link in GCR
