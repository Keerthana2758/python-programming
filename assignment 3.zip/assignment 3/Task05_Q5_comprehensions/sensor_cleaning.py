"""Q5: Cleaning sensor readings using loops, comprehensions, map/filter."""
import random
import sys
import time

def valid(c):
    return -50 <= c <= 50

def loop_version(readings):
    celsius = []
    for x in readings:
        if valid(x):
            celsius.append(x)
    fahrenheit = []
    for c in celsius:
        fahrenheit.append(c * 9 / 5 + 32)
    return celsius, fahrenheit

def comprehension_version(readings):
    celsius = [x for x in readings if valid(x)]
    fahrenheit = [c * 9 / 5 + 32 for c in celsius]
    return celsius, fahrenheit

def map_filter_version(readings):
    celsius = list(filter(lambda x: -50 <= x <= 50, readings))
    fahrenheit = list(map(lambda c: c * 9 / 5 + 32, celsius))
    return celsius, fahrenheit

def main():
    readings = [-60, -10, 2, 5, 9, 51, 4, 12, 0]
    a = loop_version(readings); b = comprehension_version(readings); c = map_filter_version(readings)
    assert a == b == c
    print("Valid Celsius:", b[0])
    print("Fahrenheit:", [round(x, 2) for x in b[1]])
    print("Alarm minute indices (0-based):", [i for i, x in enumerate(readings) if valid(x) and not 2 <= x <= 8])
    print("All valid:", comprehension_version([1, 2, 3])[0])
    print("All invalid:", comprehension_version([60, -70])[0])
    print("Dictionary comprehension:", {i: x for i, x in enumerate(readings) if valid(x)})
    print("Set comprehension:", {x for x in readings if valid(x)})

    random.seed(9)
    print("\\nTiming (seconds)")
    for n in (10_000, 100_000, 1_000_000):
        data = [random.uniform(-60, 60) for _ in range(n)]
        timings = []
        for fn in (loop_version, comprehension_version, map_filter_version):
            t0 = time.perf_counter(); result = fn(data); timings.append(time.perf_counter()-t0)
        assert loop_version(data) == comprehension_version(data) == map_filter_version(data)
        print(f"n={n:>7}: loop={timings[0]:.6f}s comprehension={timings[1]:.6f}s map/filter={timings[2]:.6f}s")
    gen = (x for x in range(1_000_000))
    materialized = [x for x in range(1_000_000)]
    print("Container size bytes:", "generator=", sys.getsizeof(gen), "list=", sys.getsizeof(materialized))

if __name__ == "__main__":
    main()
