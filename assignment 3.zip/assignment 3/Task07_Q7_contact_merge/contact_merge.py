"""Q7: Merge contacts by normalized phone number."""
import random
import re
import time

def normalize_phone(value):
    if not value:
        return ""
    digits = re.sub(r"\D", "", value)
    if digits.startswith("91") and len(digits) == 12:
        digits = digits[2:]
    return digits

def normalize_name(value):
    return " ".join(re.findall(r"[a-z]+", (value or "").lower()))

def merge_contacts(groups):
    merged = {}
    for contact in groups:
        phone = normalize_phone(contact.get("phone", ""))
        if not phone:
            # Contacts without a usable number cannot safely be merged by phone.
            continue
        entry = merged.setdefault(phone, {"names": set(), "numbers": set(), "emails": set()})
        name = normalize_name(contact.get("name", ""))
        if name:
            entry["names"].add(name)
        if contact.get("phone"):
            entry["numbers"].add(contact["phone"])
        if contact.get("email"):
            entry["emails"].add(contact["email"].strip().lower())
    return merged

def main():
    contacts = [
        {"name": "Dr. Ravi", "phone": "+91 98400 12345", "email": "ravi@example.com"},
        {"name": "ravi kumar", "phone": "9840012345", "email": "RAVI@example.com"},
        {"name": "Meena", "phone": "90000-11111", "email": "meena@example.com"},
        {"name": "Ravi", "phone": "", "email": "other@example.com"},
        {"name": "Meena R", "phone": "9000011111", "email": ""},
    ]
    print("Merged small sample:")
    for phone, record in sorted(merge_contacts(contacts).items()):
        print(phone, record)
    print("Same name, different phone stays separate:",
          len(merge_contacts([{"name":"Arun","phone":"9000011111"},
                              {"name":"Arun","phone":"9000022222"}])) == 2)

    random.seed(11)
    print("\\nTiming (seconds; dictionary grouping; pairwise benchmark at 1,000)")
    for n in (1_000, 100_000):
        data = [{"name": f"Person {i%5000}", "phone": f"+91 {9000000000 + (i%max(1,n//2))}",
                 "email": f"p{i%5000}@example.com"} for i in range(n)]
        t0 = time.perf_counter(); result = merge_contacts(data); dict_t = time.perf_counter()-t0
        print(f"contacts={n:>6}: dictionary={dict_t:.6f}s unique_phone_groups={len(result)}")
        if n == 1_000:
            t0 = time.perf_counter()
            pairs = 0
            for i in range(len(data)):
                pi = normalize_phone(data[i]["phone"])
                for j in range(i+1, len(data)):
                    if pi and pi == normalize_phone(data[j]["phone"]):
                        pairs += 1
            pair_t = time.perf_counter()-t0
            print(f"contacts={n:>6}: pairwise={pair_t:.6f}s matching_pairs={pairs}")
    print("Limitation: two people sharing one phone number may be merged incorrectly.")

if __name__ == "__main__":
    main()
