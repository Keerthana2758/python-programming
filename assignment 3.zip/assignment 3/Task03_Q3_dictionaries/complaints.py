"""Q3: Complaint word-frequency analysis with dictionaries and Counter."""
import random
import re
import time
from collections import Counter

calls = [
    "seeds not received seeds delayed",
    "fertiliser price high",
    "seeds price high subsidy not received",
]
STOP = {"not", "high"}

def frequencies(texts, stop):
    counts = {}
    for text in texts:
        for word in re.findall(r"[a-z]+", text.lower()):
            if word not in stop:
                counts[word] = counts.get(word, 0) + 1
    return counts

def top(counts, k):
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:k]

def main():
    print(top(frequencies(calls, STOP), 3))
    print("Empty text:", frequencies([""], STOP))
    print("Case/punctuation:", frequencies(["SEEDS, seeds! Price."], STOP))
    districts = {"Madurai": ["seed delay", "water issue"],
                 "Salem": ["fertiliser price"]}
    by_crop = {}
    for crop, complaint in [("rice", "pest issue"), ("cotton", "seed issue"),
                            ("rice", "water issue")]:
        by_crop.setdefault(crop, []).append(complaint)
    print("By district:", districts)
    print("By crop:", by_crop)

    random.seed(7)
    vocabulary = ["seed", "water", "price", "crop", "pest", "soil", "loan",
                  "fertiliser", "rain", "market", "delay", "subsidy"]
    print("\\nTiming (seconds; repeated small vocabulary)")
    for n in (1_000, 10_000, 100_000):
        texts = [" ".join(random.choices(vocabulary, k=8)) for _ in range(n)]
        words = [w for t in texts for w in re.findall(r"[a-z]+", t)]
        t0 = time.perf_counter(); d = frequencies(texts, set()); dict_t = time.perf_counter()-t0
        t0 = time.perf_counter(); c = Counter(words); counter_t = time.perf_counter()-t0
        distinct = set(words)
        t0 = time.perf_counter(); slow = {w: words.count(w) for w in distinct}; count_t = time.perf_counter()-t0
        assert d == c == slow
        print(f"complaints={n:>6}: dict={dict_t:.6f}s Counter={counter_t:.6f}s list.count={count_t:.6f}s words={len(words)}")

if __name__ == "__main__":
    main()
