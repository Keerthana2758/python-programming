"""Q6: Nested railway timetable and station-to-trains index."""
import random
import time

def make_timetable(count=5):
    stations = ["Chennai", "Tambaram", "Villupuram", "Trichy", "Madurai", "Salem"]
    days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}
    data = {}
    for i in range(count):
        stops = []
        start = 6 * 60 + i
        for j, station in enumerate(stations):
            arrival = start + j * 70
            departure = arrival + 5
            stops.append((station, f"{arrival//60:02d}:{arrival%60:02d}",
                          f"{departure//60:02d}:{departure%60:02d}"))
        data[f"126{i+1:02d}"] = {"name": f"Express {i+1}", "stops": stops,
                                  "days": set(days if i % 2 == 0 else {"Mon", "Wed", "Fri"})}
    return data

def build_index(timetable):
    index = {}
    for train, info in timetable.items():
        for station, arrival, departure in info["stops"]:
            index.setdefault(station, []).append(train)
    return index

def query_scan(timetable, station, day):
    result = []
    for train, info in timetable.items():
        if day in info["days"]:
            for stop in info["stops"]:
                if stop[0] == station:
                    result.append((train, info["name"], stop[2]))
                    break
    return result

def query_index(timetable, index, station, day):
    result = []
    for train in index.get(station, []):
        info = timetable[train]
        if day in info["days"]:
            departure = next(stop[2] for stop in info["stops"] if stop[0] == station)
            result.append((train, info["name"], departure))
    return result

def main():
    timetable = make_timetable(5)
    index = build_index(timetable)
    for train, info in timetable.items():
        print(train, info["name"], "| days:", ",".join(sorted(info["days"])))
        for station, arr, dep in info["stops"]:
            print(f"  {station:12} arrival {arr} departure {dep}")
    station, day = "Trichy", "Mon"
    print("Scan query:", sorted(query_scan(timetable, station, day)))
    print("Indexed query:", sorted(query_index(timetable, index, station, day)))
    print("Unknown station:", query_index(timetable, index, "Atlantis", day))
    print("Non-running day:", query_index(timetable, index, "Chennai", "Sun"))

    random.seed(3)
    print("\\nQuery timing (seconds)")
    for n in (100, 1_000, 10_000):
        data = make_timetable(n)
        t0 = time.perf_counter(); idx = build_index(data); build_t = time.perf_counter()-t0
        t0 = time.perf_counter(); x = query_scan(data, "Trichy", "Mon"); scan_t = time.perf_counter()-t0
        t0 = time.perf_counter(); y = query_index(data, idx, "Trichy", "Mon"); index_t = time.perf_counter()-t0
        assert sorted(x) == sorted(y)
        print(f"trains={n:>5}: build_index={build_t:.6f}s scan={scan_t:.6f}s indexed={index_t:.6f}s index_keys={len(idx)}")

if __name__ == "__main__":
    main()
