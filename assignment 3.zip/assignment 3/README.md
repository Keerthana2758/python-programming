# CSA08 Assignment 3 – CO3

Student: Keerthana Lathish Babu  
Register number: [Enter your register number]  
Python: Python 3.12 (standard library only)

## Libraries
Only Python standard-library modules are used. No third-party packages are required.

## Run
See `REPORT.md` for the full explanation and commands. Each Task folder contains one `.py` program and its captured `output.txt` execution record.

## Results
- Task 1: rainfall lists, slicing and moving averages
- Task 2: tuple keys, aliasing, shallow/deep copying and grid correction
- Task 3: complaint word frequencies, stop words and top-k sorting
- Task 4: set-based elective clash detection
- Task 5: sensor cleaning with loops, comprehensions and map/filter
- Task 6: nested railway timetable and station index
- Task 7: contact merging using normalized phone-number keys

## Before submission
1. Replace `[Enter your register number]` in this file and `REPORT.md`.
2. Create GitHub repository `CSA08-<RegisterNumber>-Assignment3`.
3. Upload this folder's contents and commit each task separately.
4. Run every program on your own computer and capture screenshots.
5. Add your working GitHub URL to the report and cover page.
