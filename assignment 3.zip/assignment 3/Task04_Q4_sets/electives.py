"""Q4: Elective registration clash detection using sets."""
import random
import time

def main():
    ai_elective = {"192311001", "192311004", "192311007", "192311009"}
    iot_elective = {"192311002", "192311004", "192311009", "192311010"}
    all_students = {f"1923110{i:02d}" for i in range(1, 11)}
    both = ai_elective & iot_elective
    exactly_one = ai_elective ^ iot_elective
    neither = all_students - (ai_elective | iot_elective)
    print("clash      :", sorted(both))
    print("exactly one:", sorted(exactly_one))
    print("neither    :", sorted(neither))
    print("Method check:", both == ai_elective.intersection(iot_elective),
          exactly_one == ai_elective.symmetric_difference(iot_elective),
          neither == all_students.difference(ai_elective.union(iot_elective)))

    print("\\nMembership timing (seconds; one successful lookup)")
    random.seed(2)
    for n in (10_000, 100_000, 1_000_000):
        values = list(range(n)); s = set(values); target = n - 1
        t0 = time.perf_counter(); target in values; list_t = time.perf_counter()-t0
        t0 = time.perf_counter(); target in s; set_t = time.perf_counter()-t0
        print(f"n={n:>7}: list={list_t:.8f}s set={set_t:.8f}s")
    a, b = list(range(2000)), list(range(1000, 3000))
    t0 = time.perf_counter(); nested = [x for x in a for y in b if x == y]; nested_t = time.perf_counter()-t0
    t0 = time.perf_counter(); common = set(a) & set(b); set_t = time.perf_counter()-t0
    assert set(nested) == common
    print(f"Common values: nested={nested_t:.6f}s set-intersection={set_t:.6f}s")
    print("Empty:", set() & set(), "Identical:", set(a) == set(a))

if __name__ == "__main__":
    main()
