"""Q1: Daily rainfall records — lists, slicing and moving averages."""
import random
import time

WINDOW = 7

def weekly_totals(readings):
    return [sum(readings[i:i + 7]) for i in range(0, len(readings) - 6, 7)]

def moving_average_naive(readings, window=WINDOW):
    if window <= 0:
        raise ValueError("window must be positive")
    return [sum(readings[i:i + window]) / window
            for i in range(len(readings) - window + 1)]

def moving_average_running(readings, window=WINDOW):
    if window <= 0:
        raise ValueError("window must be positive")
    if len(readings) < window:
        return []
    current = sum(readings[:window])
    result = [current / window]
    for i in range(window, len(readings)):
        current += readings[i] - readings[i - window]
        result.append(current / window)
    return result

def main():
    random.seed(42)
    readings = [round(random.uniform(0, 30), 1) for _ in range(365)]
    readings[10] = 0.0
    readings[90] = 0.0
    weeks = weekly_totals(readings)
    print("Weekly totals (first 5):", weeks[:5])
    print("Wettest week (1-based):", weeks.index(max(weeks)) + 1, "total:", max(weeks))
    print("Driest week (1-based):", weeks.index(min(weeks)) + 1, "total:", min(weeks))
    print("Maximum reading index:", readings.index(max(readings)), "value:", max(readings))
    print("Minimum reading index:", readings.index(min(readings)), "value:", min(readings))
    print("7-day moving averages (first 5):", moving_average_running(readings)[:5])
    print("Dry day indices (0-based):", [i for i, x in enumerate(readings) if x == 0])
    print("Slice readings[7:14]:", readings[7:14])
    print("Slice readings[-7:]:", readings[-7:])
    print("Slice readings[::7] (every seventh item):", readings[::7][:8], "...")

    print("\\nTiming (seconds; generated deterministic random data)")
    for n in (365, 36_500, 365_000):
        data = [random.random() * 30 for _ in range(n)]
        t0 = time.perf_counter(); a = moving_average_naive(data); naive = time.perf_counter() - t0
        t0 = time.perf_counter(); b = moving_average_running(data); running = time.perf_counter() - t0
        assert all(abs(x-y) < 1e-9 for x, y in zip(a, b))
        print(f"n={n:>6}: naive={naive:.6f}s running={running:.6f}s outputs={len(b)}")
    print("Short input:", moving_average_running([1, 2, 3]))
    print("Empty input:", moving_average_running([]))

if __name__ == "__main__":
    main()
