"""Q2: Tuples, mutability, aliasing and copying."""
import copy
import sys
import time

def main():
    rows, cols = 3, 4
    bad = [[0] * cols] * rows
    bad[0][1] = 7
    good = [[0 for _ in range(cols)] for _ in range(rows)]
    good[0][1] = 7
    print("bad :", bad)
    print("good:", good)
    print(bad[0] is bad[1], good[0] is good[1])

    stops = {(13.0827, 80.2707): "Chennai Central",
             (13.0418, 80.2341): "T. Nagar"}
    print(stops[(13.0418, 80.2341)])
    try:
        stops[[13.0418, 80.2341]] = "Invalid key"
    except TypeError as exc:
        print("List key error:", type(exc).__name__, str(exc))

    original = [[1, 2], [3, 4]]
    alias = original
    shallow = copy.copy(original)
    sliced = original[:]
    deep = copy.deepcopy(original)
    original[0][0] = 99
    print("Aliasing sees change:", alias[0][0])
    print("Shallow copy shares inner list:", shallow[0] is original[0])
    print("Slice shares inner list:", sliced[0] is original[0])
    print("Deep copy independent:", deep[0][0])

    print("Tuple unpacking:")
    for lat, lon in stops:
        print(lat, lon)

    values = list(range(1_000_000))
    tuple_values = tuple(values)
    print("Container size bytes (excluding referenced integer objects):",
          "list=", sys.getsizeof(values), "tuple=", sys.getsizeof(tuple_values))
    t0 = time.perf_counter(); list_copy = list(range(100_000)); list_create = time.perf_counter()-t0
    t0 = time.perf_counter(); tuple_copy = tuple(range(100_000)); tuple_create = time.perf_counter()-t0
    t0 = time.perf_counter(); _ = list_copy[50_000]; list_index = time.perf_counter()-t0
    t0 = time.perf_counter(); _ = tuple_copy[50_000]; tuple_index = time.perf_counter()-t0
    print(f"Create 100k: list={list_create:.6f}s tuple={tuple_create:.6f}s")
    print(f"One index: list={list_index:.9f}s tuple={tuple_index:.9f}s")

    mixed = (1, [2, 3])
    mixed[1].append(4)
    print("Tuple containing mutable list:", mixed)

if __name__ == "__main__":
    main()
