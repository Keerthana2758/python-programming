# Assignment 3 – CO3: Python Data Structures

**Student name:** Keerthana Lathish Babu  
**Register number:** [Enter your register number]  
**Course:** Python Programming (CSA08)  
**Python version used to prepare this package:** Python 3.12 (standard-library-only code; run with your installed Python 3 version)  
**Submission date:** 03/11/2026  
**GitHub repository:** `CSA08-[RegisterNumber]-Assignment3`  
**Libraries:** Python standard library only (`random`, `time`, `copy`, `sys`, `re`, `collections`). No third-party packages.

> Replace the register-number placeholder, add your GitHub URL, run each `.py` file on your own computer, and capture screenshots of your own execution for the report. `output.txt` files are text execution records, not screenshots.

## Q1 – Lists and slicing: Daily rainfall

**Design / implementation.** `rainfall.py` stores daily values in a list, creates weekly totals using seven-element slices, finds extrema, reports dry-day indices and calculates the seven-day moving average. A list is suitable because readings are ordered by date, supports indexing/slicing and can grow.

**Moving-average pseudocode**
```
if number of readings < 7: return empty list
window_sum = sum(first 7 readings)
append window_sum / 7
for each next reading:
    window_sum = window_sum - outgoing_reading + incoming_reading
    append window_sum / 7
return averages
```

`readings[7:14]` gives elements at indices 7 through 13; `readings[-7:]` gives the final seven elements; `readings[::7]` gives every seventh element beginning at index zero. `append` is amortized O(1), `insert` and `pop(0)` are O(n) because elements shift, `pop()` at the end is O(1), and `sort()` is O(n log n).

For n readings and a fixed window k=7, the naive method performs about `7(n-6)` additions, hence O(7n)=O(n). The running-sum method performs 7 initial additions and two arithmetic updates per later reading (one subtraction and one addition), hence O(n) with a smaller constant. The code handles empty and shorter-than-seven lists by returning an empty moving-average list. Inserting a late reading at its date with `list.insert()` costs O(n) in the worst case; a list remains reasonable for a year-sized dataset, while frequent out-of-order inserts may justify a date-keyed dictionary or database.

**Alternative:** A `deque(maxlen=7)` keeps only the current window; update a running sum when removing the oldest and adding the newest item. Each update is O(1), total O(n), window storage O(7). A date-keyed dictionary provides average O(1) date lookup/insertion but must be sorted or traversed in date order for chronological windows; storing all n readings costs O(n).

## Q2 – Tuples, mutability and copying

`tuples_copying.py` uses coordinate tuples as dictionary keys, creates independent grid rows with `[[0 for _ in range(cols)] for _ in range(rows)]`, and demonstrates aliasing and copying.

Tuples can be dictionary keys when all their elements are hashable because their hash remains stable. Lists are mutable and unhashable, so a list key raises `TypeError`. A shallow copy creates a new outer container but retains references to nested objects; it is enough when nested values are immutable or intentionally shared. A deep copy recursively copies nested objects. `alias = original` creates no copy. A function that mutates a list argument changes the same list object referenced by the caller.

**Aliased grid memory sketch**
```
bad ──► row A ◄── bad[0], bad[1], bad[2]
        [0, 7, 0, 0]
```
**Correct grid sketch**
```
good ──► row A [0, 7, 0, 0]
      ├─► row B [0, 0, 0, 0]
      └─► row C [0, 0, 0, 0]
```
`sys.getsizeof()` reports the container's shallow size, not the full recursively referenced memory. The program prints the measured sizes on the machine used to run it. Tuple and list indexing are both O(1); construction is O(n). A tuple containing a list is not deeply immutable: the inner list can still be changed.

**Sparse-grid alternative:** Store only occupied cells in a dictionary such as `{(row, col): passenger_count}`. Average lookup/update is O(1). A full list-of-lists uses O(rows × cols) storage; a sparse dictionary uses O(z), where z is the number of non-empty zones, plus dictionary overhead. The assignment's TODO is completed in the program.

## Q3 – Dictionaries: Farmer helpline complaints

`complaints.py` lowercases and tokenizes text, removes stop words with a set, counts using `dict.get()`, groups values using `setdefault()`, and sorts by descending count then ascending word. The completed code prints:
`[('seeds', 3), ('price', 2), ('received', 2)]`.
Price precedes received because the counts tie and alphabetical order is the tie-breaker.

A dictionary uses a hash of the key to locate a bucket; lookup is O(1) on average (worst case can degrade with collisions). Counting n words with a dictionary is O(n) average; calling `list.count()` for each of d distinct words is O(n·d). Python 3.7+ guarantees dictionary insertion order. `keys()`, `values()` and `items()` are dynamic view objects for keys, values and key-value pairs.

`collections.Counter` is a specialized frequency counter and is also O(n) average. The program times dictionary, Counter and list.count on 1,000, 10,000 and 100,000 complaints, with a fixed small vocabulary so the comparison is practical. Empty text returns an empty dictionary; case and punctuation are normalized. For 100,000 complaints, dictionary counting or Counter is the deployment choice rather than repeated `list.count()`.

**Alternative:** `Counter(all_words)` is concise and efficient. The list-count approach repeatedly scans all words once per distinct word. Both dictionary and Counter require O(d) count storage; token storage in the benchmark is O(n).

## Q4 – Sets: Elective registration clashes

`electives.py` completes the required set-operator solution:
- Both electives: `ai_elective & iot_elective`
- Exactly one: `ai_elective ^ iot_elective`
- Neither: `all_students - (ai_elective | iot_elective)`

It also checks the equivalent methods `intersection`, `symmetric_difference`, `difference` and `union`. Sets remove duplicates and provide average O(1) membership tests using hashing; list membership is O(n). Lists cannot be set elements because they are unhashable; tuples can be elements if all their members are hashable.

**Venn diagram meaning:** intersection is the overlapping region; symmetric difference is the two non-overlapping regions; union is both circles together; neither is the area outside both circles but inside the universal set. The printed sorted output is the report. Empty and identical sets are tested.

Converting a list to a set is useful when duplicate removal and repeated membership tests matter. It loses duplicate counts and does not preserve the original sequence order as a meaningful ordering. Nested-loop comparison costs O(n·m); sorting both lists costs O(n log n + m log m) then a linear merge walk O(n+m); set operations are O(n+m) average and use additional hash-table memory.

## Q5 – List comprehension: Sensor readings

`sensor_cleaning.py` removes values outside [-50, 50], converts valid Celsius values to Fahrenheit, and reports zero-based alarm-minute indices for valid temperatures outside [2, 8]. It implements a loop with `append`, list comprehensions, and `filter`/`map` with lambdas and verifies that all versions agree.

General form: `[expression for item in iterable if condition]`. A comprehension becomes harder to read when it contains several nested loops, multiple conditions, or complicated transformations; use a normal loop in that case. Dictionary comprehension: `{i: x for i, x in enumerate(readings) if valid(x)}`. Set comprehension: `{x for x in readings if valid(x)}`. A list comprehension immediately creates and stores all results (O(n) memory); a generator expression produces values lazily and typically uses O(1) additional iteration memory. Both take O(n) time to consume all values.

The program times all three approaches for 10,000, 100,000 and 1,000,000 readings and compares shallow container sizes for a generator and a list. A comprehension is not always best: choose readability and whether results need to be stored; use a generator for one-pass processing of large streams. All-valid and all-invalid inputs are included.

## Q6 – Nested data: Railway timetable

`timetable.py` builds five sample trains and larger generated timetables. Each outer dictionary key is a train number; the inner dictionary stores train name, stop list and running-day set. Each stop is a tuple `(station, arrival, departure)`. The list preserves stop order; the tuple groups a fixed record; the set supports day membership.

Expression for the departure time at the third stop of train `12601`:
`timetable["12601"]["stops"][2][2]`.

**Structure sketch**
```
timetable
  └─ train number -> {name: str, stops: [(station, arrival, departure), ...],
                      days: {Mon, Tue, ...}}
```
A scan checks up to every train and its stops: O(total stops) per query. An index maps station to train-number lists. Building it costs O(total stops) time and space; then a query examines only trains listed for that station, approximately O(trains at station × stop lookup), with extra memory for the index. The code tests unknown stations and non-running days and times scans versus indexed queries for 100, 1,000 and 10,000 trains.

**Flat-list alternative:** Store `(train, station, arrival, departure, days)` records and scan all records for each query, O(total stops). The station index reduces the candidate records to the trains serving the requested station, at the cost of O(total stops) extra references/storage. For many repeated queries, the index is worthwhile.

## Q7 – Contact merging from first principles

`contact_merge.py` normalizes phone numbers by removing non-digits and removing the leading country code `91` for 12-digit Indian numbers. Names are lowercased and punctuation is removed for consistent display keys. The dictionary is keyed by normalized phone number; each record holds sets of observed names, original phone formats and email addresses.

**Input:** contact records from several sources, with optional name, phone and email. **Output:** one grouped record per normalized phone number. **Identity rule:** matching normalized phone numbers are treated as the same contact. Missing phone numbers are skipped rather than guessed. Requirements can be checked: formatting variants normalize identically; duplicates merge; emails are deduplicated case-insensitively; two people with the same name but different phone numbers remain separate.

**Pseudocode**
```
create empty dictionary merged
for each contact:
    normalized = normalize(contact.phone)
    if normalized is empty: continue
    record = merged.setdefault(normalized, empty sets)
    add normalized name if present
    add original phone if present
    add lowercased email if present
return merged
```
Dictionary grouping is O(n) average time and O(n) storage. Comparing every pair is O(n²) time; its extra working space can be O(1) beyond the input if pairs are processed directly, while the output still requires O(n) in the worst case. The program measures dictionary grouping for 1,000 and 100,000 contacts and pairwise comparison for 1,000 contacts (a 100,000-contact all-pairs run is intentionally omitted because it would require billions of comparisons). The small sample can be checked manually: the two Ravi records with the same normalized number merge; the two Meena records merge.

**Defence / limitation:** A dictionary avoids comparing every pair and scales much better. Two different people with the same name but different phone numbers remain separate because the key is the phone, not the name. A limitation is that shared/recycled phone numbers can incorrectly combine people; contacts with no usable phone are not merged. Real deployment should add reviewed secondary identifiers and conflict handling.

## Complexity summary

| Task | Main operation | Average time | Extra space |
|---|---|---:|---:|
| Q1 | running moving average | O(n) for fixed window | O(n) output; O(1) working |
| Q2 | grid creation | O(rows × cols) | O(rows × cols) |
| Q3 | dictionary frequency count | O(n) | O(d) |
| Q4 | set union/intersection | O(n + m) | O(n + m) worst case |
| Q5 | filtering/conversion | O(n) | O(n) list; O(1) generator iteration |
| Q6 | indexed station query | O(trains at station × local stop search) | O(total stops) index |
| Q7 | dictionary contact grouping | O(n) average | O(n) |

## Execution commands

Run each program from the repository root:
```
python Task01_Q1_lists/rainfall.py
python Task02_Q2_tuples_copying/tuples_copying.py
python Task03_Q3_dictionaries/complaints.py
python Task04_Q4_sets/electives.py
python Task05_Q5_comprehensions/sensor_cleaning.py
python Task06_Q6_nested_timetable/timetable.py
python Task07_Q7_contact_merge/contact_merge.py
```

## Evaluation note

The included `output.txt` files are execution records produced while packaging this assignment. Timing values vary by computer, Python build, background load and interpreter version. Re-run the programs on your own system and use your own screenshots and timing measurements as final evidence. Be prepared to explain each function and modify test data during verification.
