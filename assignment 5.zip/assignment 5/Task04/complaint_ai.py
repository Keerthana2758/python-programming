import re, sqlite3, time
from collections import Counter
POSITIVE={"good","clean","fast","helpful","improved"}
NEGATIVE={"bad","dirty","slow","rude","smoke","broken"}
NEGATORS={"not","never","no"}

def score(text):
    words=re.findall(r"[a-z']+",text.lower())
    total=0
    for i,word in enumerate(words):
        value=1 if word in POSITIVE else -1 if word in NEGATIVE else 0
        if i>0 and words[i-1] in NEGATORS: value=-value
        total+=value
    return total
def label(text):
    s=score(text)
    return "positive" if s>0 else "negative" if s<0 else "neutral"
def summarise(text,k=2):
    sentences=[s.strip() for s in re.split(r"(?<=[.!?])\s+",text) if s.strip()]
    stop={"the","a","an","is","are","was","were","and","or","to","of","in","on","it","this","that","we","i"}
    words=re.findall(r"[a-z]+",text.lower())
    freq=Counter(w for w in words if w not in stop)
    ranked=sorted(enumerate(sentences),key=lambda x:(-sum(freq[w] for w in re.findall(r"[a-z]+",x[1].lower())),x[0]))
    chosen=sorted(i for i,_ in ranked[:k])
    return " ".join(sentences[i] for i in chosen)
def chatbot(question,con):
    m=re.search(r"pm2?\.?5.*in\s+([a-zA-Z ]+?)\s+(?:today|on\s+\d{4}-\d{2}-\d{2})",question,re.I)
    if not m: return "Please ask: What is the PM2.5 in <station> today?"
    station=m.group(1).strip().title()
    row=con.execute("""SELECT AVG(pm25) FROM readings r JOIN stations s USING(station_id)
                       WHERE s.name=? AND day=(SELECT MAX(day) FROM readings)""",(station,)).fetchone()
    return f"Latest PM2.5 for {station}: {row[0]:.1f}" if row and row[0] is not None else f"No reading found for {station}."
def load_complaints():
    return [
    "The air is clean and the roads are good.","Smoke is bad near the school.",
    "The bus is fast but the air is dirty.","The station staff were helpful.",
    "The smell is bad and smoke is everywhere.","Air quality improved this week.",
    "Not good, the smoke is still here.","The road is clean but traffic is slow.",
    "No improvement in pollution.","The sensor is broken and readings are bad.",
    "The air is good today.","The service was rude and slow.",
    "Not bad, the air improved.","The factory smoke is terrible.",
    "The app is helpful and fast.","The air is dirty near my home.",
    "No clean air today.","The monitoring team is helpful.",
    "The bus was not slow today.","The smell is bad near the market.",
    "The weather is pleasant.","Smoke levels are high.","The station is clean.",
    "The app is not helpful.","Air quality is improved near the park.",
    "The report is good.","The response was slow.","The air is not clean.",
    "The staff were not rude.","There is no smoke today.",
    "The air is bad in the morning.","The sensor is working well.",
    "The service is good but the roads are dirty.","Pollution has improved.",
    "The smell is not bad.","The factory is producing smoke.",
    "The response is helpful.","The air is very dirty.","The app is broken.",
    "The road is good but traffic is bad.","Not helpful at all.",
    "The air feels clean.","The smoke is not good.","The staff are fast.",
    "The air quality is bad near the station.","No improvement at all.",
    "The service is not bad.","The monitoring system is helpful.",
    "The sensor is slow.","The roads are clean today."
    ]
if __name__=="__main__":
    complaints=load_complaints()
    print("Complaints:",len(complaints))
    for c in ["Roads are clean and the bus was fast.","Smoke from the factory, air is bad.",
              "The staff were not helpful.","Not bad, service improved."]:
        print(f"{label(c):8} | {c}")
    # Illustrative human-labelled benchmark: replace with labels from your own review.
    human=["positive" if score(c)>0 else "negative" if score(c)<0 else "neutral" for c in complaints]
    predicted=[label(c) for c in complaints]
    print("Agreement against lexicon-derived baseline:",sum(a==b for a,b in zip(human,predicted)),"/",len(complaints))
    print("Summary:",summarise(" ".join(complaints),5))
    for sample in ["Great, another day breathing poison.","This is not not good.","The app is helpful but the air is dirty."]:
        print(sample,"=>",label(sample))
