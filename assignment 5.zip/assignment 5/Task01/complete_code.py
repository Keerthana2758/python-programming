import csv
import io
RAW = """station,date,pm25
Adyar,2026-10-01,48
Adyar,2026-10-02,NA
Adyar,2026-10-03,
Guindy,2026-10-01,95
Guindy,2026-10-02,-5
Guindy,2026-10-03,121
T Nagar,2026-10-04,1500
"""
def load_clean(text):
    rows=[]
    for row in csv.DictReader(io.StringIO(text)):
        value=row["pm25"].strip()
        if value.upper() in ("","NA"): continue
        try: pm=float(value)
        except ValueError: continue
        if pm < 0 or pm > 999: continue
        rows.append((row["station"],row["date"],pm))
    return rows
def min_max(values):
    values=list(values)
    if not values: return []
    low,high=min(values),max(values)
    if high==low: return [0.0 for _ in values]
    return [round((v-low)/(high-low),3) for v in values]
clean=load_clean(RAW)
print(clean)
print(min_max([pm for _,_,pm in clean]))
