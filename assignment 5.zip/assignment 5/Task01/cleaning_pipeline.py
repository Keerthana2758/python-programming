import csv, io, sqlite3
from pathlib import Path
import matplotlib.pyplot as plt

RAW = """station,date,pm25,pm10,no2,temperature
Adyar,2026-10-01,48,80,20,30
Adyar,2026-10-02,NA,85,22,31
Adyar,2026-10-03,,90,21,32
Guindy,2026-10-01,95,140,35,86
Guindy,2026-10-02,-5,130,30,87
Guindy,2026-10-03,121,160,40,88
T Nagar,2026-10-01,1500,200,50,29
"""

def load_clean(text):
    rows=[]
    reader=csv.DictReader(io.StringIO(text))
    required={"station","date","pm25","pm10","no2","temperature"}
    if not required.issubset(reader.fieldnames or []):
        raise ValueError("Missing required CSV columns")
    for r in reader:
        try:
            pm25=float(r["pm25"]) if r["pm25"].strip().upper() not in ("","NA") else None
            pm10=float(r["pm10"]) if r["pm10"].strip().upper() not in ("","NA") else None
            no2=float(r["no2"]) if r["no2"].strip().upper() not in ("","NA") else None
            temp=float(r["temperature"]) if r["temperature"].strip().upper() not in ("","NA") else None
            if pm25 is None or pm10 is None or no2 is None or temp is None: continue
            if any(v < 0 or v > 999 for v in (pm25,pm10,no2)): continue
            if temp < -50 or temp > 150: continue
            station=r["station"].strip().title()
            if station in {"Adyar","Guindy"}: temp=(temp-32)*5/9
            rows.append((station,r["date"].strip(),pm25,pm10,no2,round(temp,2)))
        except (ValueError, AttributeError):
            continue
    # Remove duplicate rows while preserving order
    return list(dict.fromkeys(rows))

def store(rows, db="air_quality.db"):
    con=sqlite3.connect(db)
    con.execute("""CREATE TABLE IF NOT EXISTS stations(
        station_id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS readings(
        reading_id INTEGER PRIMARY KEY, station_id INTEGER NOT NULL,
        day TEXT NOT NULL, pm25 REAL, pm10 REAL, no2 REAL, temperature_c REAL,
        FOREIGN KEY(station_id) REFERENCES stations(station_id))""")
    con.executemany("INSERT OR IGNORE INTO stations(name) VALUES (?)",
                    [(r[0],) for r in rows])
    con.executemany("""INSERT INTO readings(station_id,day,pm25,pm10,no2,temperature_c)
        VALUES ((SELECT station_id FROM stations WHERE name=?),?,?,?,?,?)""", rows)
    con.commit(); return con

def make_charts(rows, folder="charts"):
    from collections import defaultdict
    os.makedirs(folder,exist_ok=True)
    # line trend by date
    bydate=defaultdict(list); bystation=defaultdict(list); pairs=[]; hours=[]
    for r in rows:
        bydate[r[1]].append(r[2]); bystation[r[0]].append(r[2]); pairs.append((r[5],r[2]))
    dates=sorted(bydate)
    plt.figure()
    plt.plot(dates,[sum(bydate[d])/len(bydate[d]) for d in dates],marker="o")
    plt.xlabel("Date"); plt.ylabel("Mean PM2.5"); plt.title("Daily PM2.5 Trend"); plt.xticks(rotation=45); plt.tight_layout(); plt.savefig(f"{folder}/trend.png"); plt.close()
    plt.figure()
    names=sorted(bystation); plt.bar(names,[sum(bystation[n])/len(bystation[n]) for n in names])
    plt.xlabel("Station"); plt.ylabel("Mean PM2.5"); plt.title("Station Comparison"); plt.tight_layout(); plt.savefig(f"{folder}/stations.png"); plt.close()
    plt.figure()
    plt.scatter([p[0] for p in pairs],[p[1] for p in pairs])
    plt.xlabel("Temperature (C)"); plt.ylabel("PM2.5"); plt.title("Temperature vs PM2.5"); plt.tight_layout(); plt.savefig(f"{folder}/temperature_pm25.png"); plt.close()
    plt.figure()
    plt.hist([r[2] for r in rows],bins=8)
    plt.xlabel("PM2.5"); plt.ylabel("Frequency"); plt.title("PM2.5 Distribution"); plt.tight_layout(); plt.savefig(f"{folder}/distribution.png"); plt.close()

if __name__=="__main__":
    clean=load_clean(RAW)
    print("Cleaned rows:",clean)
    con=store(clean)
    print("Adyar October average:",con.execute("""SELECT AVG(pm25) FROM readings
      JOIN stations USING(station_id) WHERE name=? AND day BETWEEN ? AND ?""",
      ("Adyar","2026-10-01","2026-10-31")).fetchone()[0])
    print("Station averages:",con.execute("""SELECT name,AVG(pm25) FROM readings
      JOIN stations USING(station_id) GROUP BY name""").fetchall())
    print("Daily summary:",con.execute("""SELECT name,day,MIN(pm25),MAX(pm25),AVG(pm25),COUNT(pm25)
      FROM readings JOIN stations USING(station_id) GROUP BY name,day""").fetchall())
    make_charts(clean)
    con.close()
