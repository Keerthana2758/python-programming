# Python Programming – Assignment 5 (CO5)
**Student Name:** ____________________  
**Register Number:** ____________________  
**Course:** Python Programming (CSA08)  
**Submission Date:** ____________________  
**GitHub Repository:** ____________________

# PART A – DATA AND PROGRAM DESIGN

## A1 – Data acquisition

### A1.1 Source inspection
Each station CSV has a header and one row per hourly reading: `station,date,hour,pm25,pm10,no2,temperature`. Example: `Adyar,2026-10-01,08,48.2,80.1,21.4,30.5`. Expected quality issues include blank values (`pm25=""`), text missing markers (`NA`), negative readings (`pm10=-4`), implausibly high sensor values (`pm25=1500`), duplicate rows, invalid dates (`2026-13-45`), missing columns, wrong delimiters, inconsistent station spelling (`adyar`/`Adyar`), mixed temperature units (86°F), non-numeric strings (`no2=high`), malformed rows and encoding errors.

### A1.2 SQLite design
`stations(station_id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL)` stores one canonical station record. `readings(reading_id INTEGER PRIMARY KEY, station_id INTEGER NOT NULL, day TEXT NOT NULL, hour INTEGER NOT NULL, pm25 REAL, pm10 REAL, no2 REAL, temperature_c REAL, FOREIGN KEY(station_id) REFERENCES stations(station_id))` stores measurements. Add `UNIQUE(station_id,day,hour)` to prevent duplicate hourly observations and `CHECK` constraints for valid ranges where suitable. CSV station text maps to `stations.name`; date/hour map to `day/hour`; pollutant columns map to REAL columns; temperature is converted to Celsius before insertion. Index `(station_id,day)` supports station/date filters.

### A1.3 CSV versus SQL
1. Station's October PM2.5 average: CSV requires scanning relevant files and filtering rows; SQL uses `SELECT AVG(pm25) ... WHERE station_id=? AND day BETWEEN ? AND ?`.
2. Highest daily mean by station: CSV needs grouping in Python; SQL uses `GROUP BY station_id,day`.
3. Count valid readings per station: CSV scans and counts; SQL uses `COUNT(*) GROUP BY station_id`.
CSV is portable and easy to inspect but repeated questions require repeated parsing. SQLite centralises data, supports constraints, indexes and reusable queries.

**Alternative:** Loading CSV into pandas for every question reads and parses all n rows, O(n) per question, and uses O(n) RAM. An indexed SQLite lookup is approximately O(log n) to locate a range plus O(k) to aggregate returned rows; data remains on disk and the index consumes additional disk/RAM cache.

## A2 – Cleaning and normalisation

### A2.1 Rules
- Missing pollutant: represent as NULL; for short isolated gaps in a time series, forward-fill only when the previous reading is recent (e.g. within one hour); otherwise use the station/month median for descriptive analysis and retain a flag that the value was imputed. Do not impute temperature blindly.
- Impossible pollutant values: reject negative values and values above sensor/domain limits (use 999 as the assignment's PM2.5 upper sanity limit); log the original row.
- Duplicate station/date/hour: keep one record; if duplicates disagree, quarantine them for review rather than silently choosing one.
- Fahrenheit: convert to Celsius using `(F - 32) × 5/9` for the two known stations before aggregation.
- Invalid date, non-numeric value or malformed row: quarantine and log.

### A2.2 Normalisation
Min–max: `x'=(x-min)/(max-min)`, maps values to [0,1], useful for bounded feature scaling; if max=min, output 0 for every value. Z-score: `z=(x-mean)/standard_deviation`, centres values at zero and scales by spread; useful for comparing deviations and many statistical/ML methods. Calculate parameters from the training/reference period only to avoid leakage.

### A2.3 Formatting
Dates use ISO `YYYY-MM-DD`; timestamps use ISO 8601; station names use trimmed title case with a canonical station lookup; numbers use decimal point, dot decimal separator and consistent precision (raw measurements retain suitable precision, reports may show two decimals); missing values are SQL NULL, not text `"NA"`.

**Alternative:** Dropping missing observations is O(n), preserves observed values but can bias averages if missingness is systematic and reduces sample count. Forward fill is O(n) and preserves row count but may flatten peaks. Median imputation generally requires O(n log n) sorting (or expected linear selection); it can reduce variance and distort distributions. All can be streamed with O(1) or O(n) working space depending on whether the full column is retained; sorting typically uses O(n) space in common implementations.

## A3 – Analysis and visualisation

### A3.1 Charts
- Monthly PM2.5 trend: line chart with date on x-axis and daily mean on y-axis; reveals rises, falls and sustained episodes.
- Station comparison: bar chart of mean PM2.5 per station; makes differences between locations easy to compare.
- Temperature versus PM2.5: scatter plot; reveals association, clusters and outliers without implying causation.
- Hours with worst air: box plot by hour (or bar chart of hourly mean); box plots show spread and outliers, while hourly means rank typical pollution periods. Histogram is useful for the overall distribution but does not preserve hour labels.

### A3.2 Daily summary
A SQL view/query groups by station and day and returns `MIN(pm25)`, `MAX(pm25)`, `AVG(pm25)` and `COUNT(pm25)`. Example: `SELECT station_id,day,MIN(pm25),MAX(pm25),AVG(pm25),COUNT(pm25) FROM readings GROUP BY station_id,day`. NULL values are excluded by aggregate functions; count indicates valid observations.

**Alternative:** Python loops read n rows once and maintain a dictionary keyed by station/day containing min, max, sum and count. SQL GROUP BY also scans n rows; with a suitable index, grouping may benefit from ordered access but still generally processes the qualifying rows. Python dictionary memory is O(stations × days); SQL performs aggregation in the database and may use temporary storage, reducing application memory.

## A4 – Debugging and profiling

### A4.1 Debugging
Use temporary print statements to inspect parsed headers and a few cleaned rows. Use `assert` for invariants such as non-negative PM2.5 and Celsius conversion bounds. Configure `logging` with INFO for progress and WARNING/ERROR for rejected records, including file and line number. Use `pdb.set_trace()` or IDE breakpoints to inspect variables at the exact failing row and step through exception paths. Remove or lower debug output after validation.

### A4.2 Profiling
Use `time.perf_counter()` around end-to-end stages (read, clean, insert, query, chart). Use `timeit` for repeatable microbenchmarks such as list processing versus vectorised pandas. Use `cProfile` to identify cumulative time by function and optimise the measured bottleneck rather than guessing.

**Alternative:** Print calls are simple but thousands of console writes can slow execution and overwhelm useful output. Logging has configurable levels and handlers; set the level to WARNING or disable the debug logger in production. A debugger is interactive and normally incurs no stepping cost when inactive. Avoid per-row prints; aggregate counters and log a periodic summary.

## A5 – AI design for complaints

### A5.1 Sentiment and summary
A lexicon assigns +1 to positive terms and -1 to negative terms. A preceding negator (`not`, `never`, `no`) flips the next sentiment word. Sum scores: positive/negative/neutral according to sign. An extractive summary splits text into sentences, removes common stop words, counts important terms and selects the top-scoring sentences while preserving original order.

### A5.2 Chatbot
A rule-based chatbot detects a PM2.5 question and station name, then executes a parameterised SQL query for the latest station reading. It should ask for clarification if station/date is missing. Limitations: fixed wording, limited entity recognition, no context memory, weak handling of spelling variations, sarcasm and complex multi-part questions.

**Alternative ML approach:** A Naive Bayes model needs labelled examples and vectorisation; inference is usually fast after training and model memory is modest. A pre-trained language model can understand context and paraphrase better but needs much more memory/compute and may be slower. Lexicons are transparent and lightweight but less accurate for sarcasm, domain language and long-range negation. Select based on measured accuracy, latency, privacy and deployment resources.

# PART B – IMPLEMENTATION AND EXPERIMENTAL INVESTIGATION

## B1 – Cleaning pipeline
`Task01/cleaning_pipeline.py` uses `csv.DictReader`, rejects missing/non-numeric/negative/impossibly high readings, canonicalises station names, converts the two Fahrenheit stations to Celsius, removes exact duplicates, stores rows in SQLite with `executemany`, runs SQL summaries and creates line, bar, scatter and histogram charts. `Task01/complete_code.py` completes the two TODOs and includes a test row above 999.

**Expected complete-code output:**
```
[('Adyar', '2026-10-01', 48.0), ('Guindy', '2026-10-01', 95.0), ('Guindy', '2026-10-03', 121.0)]
[0.0, 0.644, 1.0]
```
The implementation additionally rejects values greater than 999. A limitation of the compact demonstration is that missing values are dropped rather than imputed; the full design keeps NULL/imputation flags for production.

Chart interpretation: the line chart shows the daily average direction; the bar chart highlights station differences; the scatter chart shows whether temperature and PM2.5 appear associated; the histogram shows the frequency distribution and possible extreme values. Sample data is deliberately small, so conclusions are illustrative only.

**Pandas alternative:** `read_csv`, `replace(["NA",""],NaN)`, numeric conversion, `dropna`, range filters and vectorised `(s-s.min())/(s.max()-s.min())`. For 1,000 rows pandas startup overhead can outweigh vectorisation; at 100,000 and 1,000,000 rows vectorised operations are often faster but use memory proportional to the DataFrame and temporary arrays. Run benchmarks on the submission machine and record actual timings rather than inventing results.

## B2 – Adversarial data
`Task02/adversarial_inputs.py` tests missing columns, semicolon delimiter, Latin-1 encoding read as UTF-8 and empty input. Missing columns and wrong delimiter are rejected by schema validation; encoding mismatch raises `UnicodeDecodeError`; an empty file has no header and is rejected. A quote in a station name can break string-concatenated SQL or enable injection. Parameterised SQL treats the entire value as data.

`Task02/adversarial_sql.py` completes the code. Expected values are `54.0 108.0` and `None`. The injection string returns None because `station = ?` compares the station column to the exact literal string `Adyar' OR '1'='1`; it is not parsed as SQL syntax.

String concatenation can turn the injected input into a condition that is always true, potentially returning an aggregate over all rows. A placeholder prevents this. `executemany()` reduces Python-to-database call overhead and is convenient for batches; both looped `execute()` and `executemany()` insert n rows, but the latter is generally faster due to lower call overhead. Use a transaction for both.

## B3 – Loops vs libraries vs SQL
`Task03/benchmark_methods.py` generates 1, 12 and 120 stations × 8,760 hourly records, compares dictionary-based Python aggregation, pandas groupby when installed, and SQLite GROUP BY. It checks results on small data and records timings; cProfile output is written to `profile.txt`. Timings are hardware- and version-dependent; run the script and paste your observed values in the table below.

| Stations | Rows | Python loop (s) | pandas (s) | SQL incl. load (s) |
|---:|---:|---:|---:|---:|
| 1 | 8,760 | ______ | ______ | ______ |
| 12 | 105,120 | ______ | ______ | ______ |
| 120 | 1,051,200 | ______ | ______ | ______ |

Expected complexity: all three methods must inspect the input rows, so aggregation is O(n) expected time. Python dictionary aggregation uses O(groups) memory. Pandas generally holds O(n) data plus intermediate memory. SQL stores rows in the database and may use temporary grouping storage. For one-time small analysis, pandas is concise; for daily automated reports, SQLite provides durable storage, repeatable queries and indexes. A running sum/count dictionary computes means in one pass, O(n) time and O(stations × days) memory, versus O(n) storage if all readings are retained.

## B4 – Final engineering decision
`Task04/complaint_ai.py` includes 50 sample complaints, a negation-aware lexicon scorer, extractive summariser and rule-based chatbot function. Manually label the 50 complaints and replace the self-consistency placeholder in the script with your own agreement count. The current sample output is not a genuine human accuracy measurement until that manual review is completed.

Add `CREATE INDEX idx_readings_station_day ON readings(station_id,day)` and compare repeated station/date queries before and after the index using `time.perf_counter()` over multiple runs. For tiny sample tables, index creation can make queries slower due to overhead; benefits become clearer with large data and selective filters.

**Production decision:** Store raw files immutably for audit, validate schema and encoding at ingestion, clean and normalise values with explicit quality flags, and load accepted readings into SQLite initially. At higher ingestion rates and multi-user concurrency, migrate to PostgreSQL or another server database. Use indexes on station/date, batch inserts and scheduled aggregate tables. Use SQL for routine summaries and pandas for exploratory analysis; profile before scaling. The lexicon and extractive summary are useful as a transparent first-pass triage tool, but 50,000 monthly complaints require a manually labelled validation set. If accuracy is insufficient, train/evaluate a domain-specific classifier and retain human review for uncertain or safety-critical complaints.

## Experimental record to complete before submission
Record Python version, pandas and matplotlib versions, machine details, actual B3 timings, cProfile's top cumulative-time function, B4 human-labelled sentiment agreement, and indexed/unindexed query timings. Do not submit invented measurements.
