# Assignment 5 – Python Programming (CSA08), CO5
Student: ____________________
Register Number: ____________________
Python: Python 3.10+
Libraries: Python standard library; pandas and matplotlib optional for Task 1 charts / Task 3 pandas comparison.
GitHub repository: add URL to report and cover page.

## Install
`pip install -r requirements.txt`

## Run
- Task 1: `cd Task01 && python complete_code.py` and `python cleaning_pipeline.py`
- Task 2: `cd Task02 && python adversarial_sql.py`; `python adversarial_inputs.py`
- Task 3: `cd Task03 && python benchmark_methods.py`
- Task 4: `cd Task04 && python complaint_ai.py`

## Results
Task 1 cleans sample sensor readings, stores them in SQLite, queries summaries and generates charts. Task 2 demonstrates malformed inputs and safe SQL parameters. Task 3 compares loop, pandas and SQL aggregation with generated data and cProfile. Task 4 analyses 50 sample complaints using sentiment, summary and chatbot functions.

## Submission note
Run all programs on your own computer, add actual output screenshots and measured timings, manually review complaint labels, and commit each task separately to `CSA08-<RegisterNumber>-Assignment5`.
