Run `python adversarial_sql.py` for the expected averages and injection-safe result. Run `python adversarial_inputs.py` for malformed CSV/encoding tests.
