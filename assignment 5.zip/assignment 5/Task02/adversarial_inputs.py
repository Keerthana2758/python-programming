from pathlib import Path
import csv, io, sqlite3

def inspect_csv(path):
    try:
        with open(path,"r",encoding="utf-8",newline="") as f:
            reader=csv.DictReader(f)
            if not reader.fieldnames or not {"station","date","pm25"}.issubset(reader.fieldnames):
                raise ValueError("required columns missing or delimiter incorrect")
            return list(reader)
    except UnicodeDecodeError as e:
        return f"encoding error: {e}"
    except (OSError,ValueError,csv.Error) as e:
        return f"input error: {e}"

samples={
 "missing_column.csv":"station,date\nAdyar,2026-10-01\n",
 "wrong_delimiter.csv":"station;date;pm25\nAdyar;2026-10-01;22\n",
 "empty.csv":""
}
for name,data in samples.items(): Path(name).write_text(data,encoding="utf-8")
Path("latin1.csv").write_bytes("station,date,pm25\nCafé,2026-10-01,10\n".encode("latin-1"))
for name in [*samples,"latin1.csv"]: print(name,inspect_csv(name))
# Unsafe construction is intentionally shown only as a demonstration.
name="Adyar' OR '1'='1"
unsafe=f"SELECT AVG(pm25) FROM aq WHERE station = '{name}'"
print("Unsafe SQL text:",unsafe)
