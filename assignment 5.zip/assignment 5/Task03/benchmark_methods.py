import csv, sqlite3, time, cProfile, pstats, io, random
from collections import defaultdict
from pathlib import Path
try:
    import pandas as pd
except ImportError:
    pd=None

def generate(path,stations,days=365):
    with open(path,"w",newline="",encoding="utf-8") as f:
        w=csv.writer(f); w.writerow(["station","day","pm25"])
        for s in range(stations):
            for d in range(days*24):
                w.writerow([f"S{s:03}",f"2026-{1+d//(24*30):02}-{1+(d//24)%28:02}",float((s*7+d)%180)])

def loop_method(path):
    sums=defaultdict(float); counts=defaultdict(int)
    with open(path,encoding="utf-8") as f:
        for r in csv.DictReader(f):
            key=(r["station"],r["day"]); sums[key]+=float(r["pm25"]); counts[key]+=1
    return {k:sums[k]/counts[k] for k in sums}

def sql_method(path):
    con=sqlite3.connect(":memory:")
    con.execute("CREATE TABLE readings(station TEXT, day TEXT, pm25 REAL)")
    with open(path,encoding="utf-8") as f:
        con.executemany("INSERT INTO readings VALUES (?,?,?)",
          ((r["station"],r["day"],float(r["pm25"])) for r in csv.DictReader(f)))
    result=dict(con.execute("SELECT station||'|'||day,AVG(pm25) FROM readings GROUP BY station,day"))
    con.close(); return result

def pandas_method(path):
    if pd is None: return None
    df=pd.read_csv(path)
    return df.groupby(["station","day"])["pm25"].mean()

def measure(fn,*args):
    start=time.perf_counter(); result=fn(*args); return time.perf_counter()-start,result

if __name__=="__main__":
    for stations in (1,12,120):
        file=f"data_{stations}.csv"; generate(file,stations)
        t1,a=measure(loop_method,file); t2,b=measure(sql_method,file)
        print(stations,"stations rows",stations*8760,"loop",round(t1,3),"s SQL-load+group",round(t2,3),"s")
        if pd is not None:
            t3,c=measure(pandas_method,file); print("pandas",round(t3,3),"s")
        if stations==1:
            pr=cProfile.Profile(); pr.enable(); loop_method(file); pr.disable()
            stream=io.StringIO(); pstats.Stats(pr,stream=stream).sort_stats("cumtime").print_stats(8)
            Path("profile.txt").write_text(stream.getvalue(),encoding="utf-8")
