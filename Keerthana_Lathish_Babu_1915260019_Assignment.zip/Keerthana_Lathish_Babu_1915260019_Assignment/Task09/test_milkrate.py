from decimal import Decimal
from milkrate import rate_per_litre, payout, validate_entry, ten_day_total
assert rate_per_litre(3.5,8.5) == Decimal("30.00")
assert rate_per_litre(4.2,8.7) == Decimal("33.40")
assert rate_per_litre(3.1,8.3) == Decimal("27.80")
assert rate_per_litre(2.0,8.5) == Decimal("24.00")
assert rate_per_litre(7.0,8.5) == Decimal("44.00")
assert payout(10,3.5,8.5) == Decimal("300.00")
for args in [("F1",-1,3.5,8.5,"morning"),("F1",10,1.9,8.5,"morning"),
             ("F1",10,7.1,8.5,"morning"),("",10,3.5,8.5,"morning"),
             ("F1",10,3.5,8.5,"night")]:
    try: validate_entry(*args)
    except ValueError: pass
    else: raise AssertionError(args)
five=[validate_entry("F1",10,3.5,8.5,"morning"),
      validate_entry("F1",8.5,4.2,8.7,"evening"),
      validate_entry("F1",12,3.1,8.3,"morning"),
      validate_entry("F1",5,3.6,8.5,"evening"),
      validate_entry("F1",6,3.5,8.6,"morning")]
assert ten_day_total(five) == Decimal("1245.30")
print("All unit tests passed. Five-entry total: Rs", ten_day_total(five))
