from decimal import Decimal
from milkrate import validate_entry, payout, ten_day_total
def main():
    """Read a series of entries and print payments and total."""
    entries=[]
    while True:
        try:
            fid=input("Farmer ID: ").strip()
            litres=Decimal(input("Litres: ").strip())
            fat=Decimal(input("Fat %: ").strip())
            snf=Decimal(input("SNF %: ").strip())
            shift=input("Shift (morning/evening): ").strip().lower()
            e=validate_entry(fid,litres,fat,snf,shift)
            entries.append(e)
            print(f"Payment: Rs {payout(litres,fat,snf):8.2f}")
        except ValueError as err: print("Invalid entry:",err)
        if input("Another entry? (y/n): ").strip().lower() != "y": break
    print(f"Ten-day total: Rs {ten_day_total(entries):.2f}")
if __name__ == "__main__": main()
