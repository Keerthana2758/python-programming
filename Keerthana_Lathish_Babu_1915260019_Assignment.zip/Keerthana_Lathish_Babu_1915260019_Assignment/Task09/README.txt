Run from this folder: python test_milkrate.py
The local test suite uses assertions and prints the five-entry total on success.
