from dataclasses import dataclass
from decimal import Decimal
@dataclass
class MilkEntry:
    farmer_id: str
    litres: Decimal
    fat_percent: Decimal
    snf_percent: Decimal
    shift: str
