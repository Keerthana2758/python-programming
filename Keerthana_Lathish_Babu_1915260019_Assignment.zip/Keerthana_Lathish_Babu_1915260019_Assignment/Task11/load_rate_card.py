import json
from decimal import Decimal
with open("rate_card.json",encoding="utf-8") as f: raw=json.load(f)
rate_card={k:Decimal(v) for k,v in raw.items()}
print(rate_card)
