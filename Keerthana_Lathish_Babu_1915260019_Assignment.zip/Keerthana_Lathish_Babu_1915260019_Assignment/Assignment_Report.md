# Assignment Report
## Design, Implement and Validate a Payment Calculator for a Village Milk Co-operative
**Student:** Keerthana Lathish Babu  
**Register Number:** 1915260019  
**Assignment:** CSA08 – Assignment 1, Tasks 1–12

## Common design assumptions
Reference composition is 3.5% fat and 8.5% SNF at Rs 30/L. Each nearest 0.1 percentage-point fat step changes the rate by Rs 0.40/L; each SNF step changes it by Rs 0.30/L. Fat limits are 2.0–7.0%, as stated in the assignment. SNF limits are assumed as 0.0–15.0% because the assignment does not specify them; confirm this with faculty. Litres must be positive. The shift is morning or evening. Percentage steps use Decimal and ROUND_HALF_UP. Monetary amounts are rounded to two decimals per entry and then summed.

## Task 1 – Problem analysis (4)
Inputs: farmer ID (string, preserves letters and leading zeroes), litres (Decimal, fractional litres), fat and SNF percentages (Decimal), shift (string). Outputs: unit rate, entry payment, and ten-day total, all represented as Decimal currency. Constants: base rate 30.00, fat adjustment 0.40, SNF adjustment 0.30, references 3.5 and 8.5, step 0.1, and validation limits. IDs and shifts are text; counts are integers; quantity, percentages and money are fractional numeric values. Rules: nonblank ID, litres > 0, fat 2–7%, SNF assumed 0–15%, supported shift only. No deductions, taxes or other charges are specified. A list of records scales better than separately named litres1/fat1/snf1 variables: both process in O(n), but lists use one uniform loop and avoid 3n separately named variables. Storing records costs O(n) space.

## Task 2 – Values and types (4)
Interpreter evidence:
```py
>>> type(10), type(10.0), type("10"), type(True), type([10,8.5])
(int, float, str, bool, list)
>>> 7/2, 7//2, 7%2, -7//2
(3.5, 3, 1, -4)
>>> 0.1+0.2 == 0.3
False
>>> from decimal import Decimal
>>> Decimal("0.1")+Decimal("0.2")==Decimal("0.3")
True
```
`/` is true division; `//` floors toward negative infinity; `%` is remainder. Binary floats approximate decimal fractions. `Decimal` created from strings is exact for these decimal inputs. Completed TODO in `Task02/decimal_demo.py` accumulates `Decimal(amount)` and returns Decimal 33400.30. `Decimal(float(amount))` preserves the float approximation and is not equivalent. Integer paise is also exact if all amounts are whole paise. `round(float)` does not make binary float a preferred accounting type. Both loops are O(n) time and O(1) extra space.

## Task 3 – Variables and constants (3)
Use uppercase names for constants and snake_case for variables/functions. Python constants are conventions, not enforced immutable bindings. Dynamic typing allows `v=10` followed by `v="ten"`; the name then refers to a string. Multiple assignment swaps values with `a,b=b,a`. Magic numbers may require k edits for a rate revision; named constants need one edit per parameter. A rate-card dictionary groups parameters and supports seasons. For a fixed number of values, runtime and storage are O(1).

## Task 4 – Expressions (4)
`fat_steps=round((fat-3.5)/0.1)`, `snf_steps=round((snf-8.5)/0.1)`, `rate=30+fat_steps*0.40+snf_steps*0.30`, `amount=round(litres*rate,2)` (the code uses Decimal quantization). Parentheses define intended order; multiplication precedes addition. `-2**2` is -4 while `(-2)**2` is 4. Surprises: `(4.2-3.5)/0.1` may be 7.000000000000001 due to binary representation; `0.1+0.2==0.3` is False; `-7//2` is -4 because floor division rounds down. `round(-1.5)` is -2 (ties-to-even), `int(-1.5)` is -1 (truncate toward zero), and `floor(-1.5)` is -2. `2.0 <= fat <= 7.0` is a chained comparison. For fat=4.2, round/floor yield +7 steps while int yields +6; for fat=3.1, round/floor yield -4 while int yields -3. Each is O(1) time and space.

## Task 5 – Input and conversion (3)
`input()` returns strings. Strip whitespace, then convert to Decimal or float inside try/except ValueError. `8.5` and ` 8.5 ` are accepted; `8,5` and `eight` are rejected with a clear message. String pre-checks are less comprehensive than conversion inside try/except. Format money with an f-string such as `{amount:8.2f}`. Parsing is O(1) per entry.

## Task 6 – Functions (4)
`rate_per_litre(fat,snf)` returns a unit rate; `payout(litres,fat,snf)` returns an entry amount; `validate_entry(...)` validates and normalises input; `ten_day_total(entries)` returns the total. Returning values separates computation from display and makes tests possible. Local variables belong to the call; functions read module constants without modifying them. Docstrings describe each function. A long script repeats logic; lambdas are suitable for short expressions but not complex validation. Function-call overhead is constant; total remains O(n).

## Task 7 – Modules (4)
`milkrate.py` stores constants and functions. `import milkrate`, `from milkrate import payout`, and `import milkrate as mr` differ in name access and namespace. The `if __name__=="__main__"` guard runs examples only on direct execution, not import. Python searches the script/current directory and `sys.path`; imported modules are cached in `sys.modules`. Both TODOs are completed: rate calculation uses nearest 0.1 steps and rounds to paisa; payout multiplies litres by rate and rounds to paisa. Run `python milkrate.py`, then `python demo_import.py` from Task07.

## Task 8 – Algorithm and pseudocode (4)
Algorithmic steps: understand, plan, write, test. Pseudocode, Mermaid flowchart and hand trace are in `Task08/pseudocode.txt`. Hand trace: 10 L at reference = Rs 300.00; 8.5 L at 4.2/8.7 = Rs 283.90; 12 L at 3.1/8.3 = Rs 333.60; total Rs 917.50. Storing all entries is O(n) space and supports audit/recalculation; running total is O(1) extra space. Both take O(n) time.

## Task 9 – Implementation and tests (4)
Run `python test_milkrate.py` from Task09. Assertions test reference, above/below standard, fat boundaries 2.0 and 7.0, invalid negative quantity, invalid fat, blank ID and invalid shift. A five-entry sample totals Rs 1,245.30. Automated assertions can be rerun consistently after every code change; manual testing takes longer and is more error-prone. Expected and actual values are compared using Decimal equality.

## Task 10 – Expectations vs execution (4)
`Task10/benchmark.py` uses `time.perf_counter()` for 300, 6,000 and 150,000 payments. Decimal should equal the exact bank total; float may differ slightly due to binary representation. Timing depends on the machine, so run the script and retain its actual output. Rounding each entry to paisa then summing matches entry-level bank settlement; rounding only the final total can differ if individual values contain fractions of a paisa. A dictionary cache for k distinct (fat,SNF) pairs gives average O(1) lookup per entry and O(k) memory; without caching, a fixed calculation is O(1) per entry. Cache only if repeated pairs and profiling justify it.

## Task 11 – Final recommendation (4)
Retain the modular architecture and modify it to use Decimal throughout, centralised rates, validation, and automated tests. Round each farmer's payment to paisa before accumulating. A JSON rate card is in Task11: reading t values takes O(t) startup time and O(t) space, but revisions can be made without editing source. Limitations: SNF range and tie policy need official confirmation; this prototype has no database, authentication, duplicate detection, audit log, concurrency control or bank integration. Processing is O(n), suitable algorithmically for 150,000 entries; production use should add persistent storage and transactional batch processing.

## Task 12 – Day-4 design challenge (8)
Decision: MODIFY. Keep module/functions and Decimal, add seasonal rate-card selection, retain two-decimal analyser readings, and apply bonus using the farmer's ten-day total. April–June base rate is Rs 32.00 and fat step Rs 0.45; SNF step remains Rs 0.30 because no change is specified. For 4.25% fat and 8.65% SNF, nearest half-up steps are +8 and +2. Regular rate = 30 + 8(0.40) + 2(0.30) = Rs 33.80/L. April–June rate = 32 + 8(0.45) + 2(0.30) = Rs 36.20/L. If a 100 L entry belongs to a farmer with 550 L in the ten-day period, bonus is 0.50/L and payment is Rs 3,670.00. At exactly 500 L, no bonus applies and payment is Rs 3,620.00. Bonus therefore requires aggregation by farmer before final settlement. Tests are in `Task12/test_seasonal.py`.

## Complexity summary
| Operation | Time | Extra space |
|---|---:|---:|
| Process n records | O(n) | O(1) streaming / O(n) stored |
| One rate calculation | O(1) | O(1) |
| Sum n Decimal payments | O(n) | O(1) |
| Cache k distinct rates | O(1) average lookup | O(k) |
| Read t rate-card values | O(t) startup | O(t) |

## Submission checklist
Create the GitHub repository named `CSA08-1915260019-Assignment1`, upload these files, commit progressively (at least one commit per task), and share it with faculty. Add the real GitHub URL to the cover page and README. This package does not publish a repository or fabricate a commit history. Run the programs yourself and add screenshots of your own execution to each task folder before final submission. Python 3.10+; standard library only.
