from decimal import Decimal
def parse_number(text):
    try: return Decimal(text.strip())
    except Exception as exc: raise ValueError("Use a valid number, e.g. 8.5") from exc
for sample in ["8.5", " 8.5 ", "8,5", "eight"]:
    try: print(repr(sample), "->", parse_number(sample))
    except ValueError as exc: print(repr(sample), "-> INVALID:", exc)
