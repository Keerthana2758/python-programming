from decimal import Decimal
from time import perf_counter
def benchmark(n):
    """Measure sequential float and Decimal accumulation for n payments."""
    values = ["33.40"] * n + ["0.10"] * 3
    t = perf_counter()
    f = 0.0
    for value in values: f += float(value)
    tf = perf_counter() - t
    t = perf_counter()
    d = Decimal("0.00")
    for value in values: d += Decimal(value)
    td = perf_counter() - t
    return f, d, tf, td
if __name__ == "__main__":
    for n in (300, 6000, 150000):
        f,d,tf,td = benchmark(n)
        print(n, "float", repr(f), "Decimal", d, "difference", Decimal(str(f))-d, "seconds", tf, td)
