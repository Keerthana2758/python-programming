import math
print((4.2 - 3.5) / 0.1, round((4.2 - 3.5) / 0.1))
print(round(-1.5), int(-1.5), math.floor(-1.5))
print(0.1 + 0.2, 0.1 + 0.2 == 0.3)
fat_steps = round((4.2 - 3.5) / 0.1)
snf_steps = round((8.7 - 8.5) / 0.1)
print(fat_steps, snf_steps, 30 + fat_steps * 0.40 + snf_steps * 0.30)
