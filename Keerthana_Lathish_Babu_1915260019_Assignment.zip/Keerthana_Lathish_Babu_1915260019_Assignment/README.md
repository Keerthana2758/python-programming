# CSA08-1915260019-Assignment1

**Student:** Keerthana Lathish Babu  
**Register number:** 1915260019  
**Python:** 3.10+  
**Libraries:** Standard library only (`decimal`, `time`, `json`, `dataclasses`, `math`).  
**requirements.txt:** No third-party dependencies.

## Run
- `python Task02/decimal_demo.py`
- `python Task04/expressions.py`
- `python Task05/input_demo.py`
- `python Task06/functions_demo.py`
- `python milkrate.py` from `Task07/`
- `python demo_import.py` from `Task07/`
- `python test_milkrate.py` from `Task09/`
- `python benchmark.py` from `Task10/`
- `python seasonal_milkrate.py` and `python test_seasonal.py` from `Task12/`

## Results
Task 2 demonstrates float error and Decimal exactness. Task 7 contains both completed TODOs and import demo. Task 8 contains pseudocode, trace and flowchart. Task 9 has assertion-based validation tests. Task 10 benchmarks 300, 6,000 and 150,000 amounts. Task 12 implements seasonal rates and volume bonus.

## GitHub requirement
Create repository `CSA08-1915260019-Assignment1`, upload this package, commit progressively (one commit per task), and share with faculty. **GitHub URL: ADD YOUR REAL REPOSITORY LINK HERE.** This offline package cannot create a remote GitHub repository or commit history.

Before submission, run the programs on your computer and add your own execution screenshots. SNF limits and half-step rounding assumptions should be confirmed with faculty.
