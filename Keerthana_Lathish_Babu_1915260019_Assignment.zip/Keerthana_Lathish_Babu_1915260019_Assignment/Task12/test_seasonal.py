from decimal import Decimal
from seasonal_milkrate import seasonal_rate,ten_day_payment
assert seasonal_rate("4.25","8.65","regular")==Decimal("33.80")
assert seasonal_rate("4.25","8.65","april_june")==Decimal("36.20")
assert ten_day_payment(100,"4.25","8.65","april_june",550)==Decimal("3670.00")
assert ten_day_payment(100,"4.25","8.65","april_june",500)==Decimal("3620.00")
print("Seasonal and bonus tests passed.")
