"""Seasonal rates and ten-day volume bonus."""
from decimal import Decimal, ROUND_HALF_UP
CENT=Decimal("0.01"); STEP=Decimal("0.1")
RATE_CARDS={"regular":{"base":Decimal("30.00"),"fat":Decimal("0.40")},
            "april_june":{"base":Decimal("32.00"),"fat":Decimal("0.45")}}
def money(x):
    """Round currency to paisa."""
    return Decimal(x).quantize(CENT,rounding=ROUND_HALF_UP)
def steps(x,ref):
    """Round analyser reading difference to nearest 0.1 percentage step."""
    return ((Decimal(str(x))-Decimal(ref))/STEP).quantize(Decimal("1"),rounding=ROUND_HALF_UP)
def seasonal_rate(fat,snf,season="regular"):
    """Calculate unit rate from selected season's rate card."""
    if season not in RATE_CARDS: raise ValueError("Unknown season")
    c=RATE_CARDS[season]
    return money(c["base"]+steps(fat,"3.5")*c["fat"]+steps(snf,"8.5")*Decimal("0.30"))
def ten_day_payment(litres,fat,snf,season,ten_day_litres):
    """Apply Rs 0.50/L bonus only when ten-day volume is greater than 500 L."""
    bonus=Decimal("0.50") if Decimal(str(ten_day_litres))>500 else Decimal("0.00")
    return money(Decimal(str(litres))*(seasonal_rate(fat,snf,season)+bonus))
if __name__=="__main__":
    print("Regular:",seasonal_rate("4.25","8.65","regular"))
    print("April-June:",seasonal_rate("4.25","8.65","april_june"))
    print("With bonus:",ten_day_payment(100,"4.25","8.65","april_june",550))
