import milkrate as mr
if __name__ == "__main__":
    print("Imported payout:", mr.payout(8.5,4.2,8.7))
