"""Reusable rate card and payment functions."""
from decimal import Decimal, ROUND_HALF_UP
BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
REFERENCE_FAT = Decimal("3.5")
REFERENCE_SNF = Decimal("8.5")
STEP_SIZE = Decimal("0.1")
MIN_FAT, MAX_FAT = Decimal("2.0"), Decimal("7.0")
MIN_SNF, MAX_SNF = Decimal("0.0"), Decimal("15.0")
CENT = Decimal("0.01")
def money(value):
    """Round money to the nearest paisa."""
    return Decimal(value).quantize(CENT, rounding=ROUND_HALF_UP)
def rate_per_litre(fat, snf):
    """Return rate per litre using nearest 0.1 percentage steps."""
    fat, snf = Decimal(str(fat)), Decimal(str(snf))
    fs = ((fat-REFERENCE_FAT)/STEP_SIZE).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    ss = ((snf-REFERENCE_SNF)/STEP_SIZE).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return money(BASE_RATE + fs*FAT_STEP_VALUE + ss*SNF_STEP_VALUE)
def payout(litres, fat, snf):
    """Return one entry payment rounded to paisa."""
    return money(Decimal(str(litres))*rate_per_litre(fat,snf))
def validate_entry(farmer_id, litres, fat, snf, shift):
    """Validate and return a normalised collection entry."""
    if not str(farmer_id).strip(): raise ValueError("Farmer ID is required")
    litres, fat, snf = Decimal(str(litres)), Decimal(str(fat)), Decimal(str(snf))
    if litres <= 0: raise ValueError("Litres must be positive")
    if not MIN_FAT <= fat <= MAX_FAT: raise ValueError("Fat must be 2.0 to 7.0")
    if not MIN_SNF <= snf <= MAX_SNF: raise ValueError("SNF must be 0.0 to 15.0 (assumed)")
    if shift not in ("morning","evening"): raise ValueError("Invalid shift")
    return dict(farmer_id=str(farmer_id), litres=litres, fat=fat, snf=snf, shift=shift)
def ten_day_total(entries):
    """Sum already rounded payments for the ten-day period."""
    return money(sum((payout(e["litres"],e["fat"],e["snf"]) for e in entries), Decimal("0.00")))
if __name__ == "__main__":
    for l,f,s in [(10,3.5,8.5),(8.5,4.2,8.7),(12,3.1,8.3)]:
        rate=rate_per_litre(f,s)
        print(f"{l:5} L  fat {f}  snf {s}  rate {rate:6.2f}  pay {payout(l,f,s):8.2f}")
