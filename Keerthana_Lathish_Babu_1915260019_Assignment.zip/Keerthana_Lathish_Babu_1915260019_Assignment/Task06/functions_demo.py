from decimal import Decimal, ROUND_HALF_UP
def rate_per_litre(fat, snf):
    """Calculate milk rate per litre."""
    f = ((Decimal(str(fat))-Decimal("3.5"))/Decimal("0.1")).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    s = ((Decimal(str(snf))-Decimal("8.5"))/Decimal("0.1")).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return Decimal("30")+f*Decimal("0.40")+s*Decimal("0.30")
def payout(litres, fat, snf):
    """Calculate rounded payment for one entry."""
    return (Decimal(str(litres))*rate_per_litre(fat,snf)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
if __name__ == "__main__": print(payout(8.5,4.2,8.7))
