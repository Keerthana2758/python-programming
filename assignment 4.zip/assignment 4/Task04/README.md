Run: `python returns_processor.py` after removing old returns.log/errors.log if a clean demonstration is required. The program appends each day's returns and logs errors.
