from pathlib import Path
from datetime import datetime

def save_returns(books, log_path="returns.log"):
    with open(log_path, "a", encoding="utf-8") as log:
        for book in books:
            if book.strip():
                log.write(book.rstrip("\n") + "\n")

def process(day_file, log_path="returns.log", error_path="errors.log"):
    try:
        with open(day_file, "r", encoding="utf-8") as source:
            books = [line.rstrip("\n") for line in source]
        save_returns(books, log_path)
        return True
    except (FileNotFoundError, PermissionError, UnicodeDecodeError, OSError) as exc:
        with open(error_path, "a", encoding="utf-8") as error_log:
            error_log.write(f"{datetime.now().isoformat()} | {day_file} | {type(exc).__name__}: {exc}\n")
        return False

if __name__ == "__main__":
    for day in ("day1.txt", "day2.txt", "day3.txt"):
        process(day)
    print(Path("returns.log").read_text(encoding="utf-8"))
