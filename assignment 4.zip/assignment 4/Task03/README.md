Run: `python complete_code.py`. Expected: `(1, 1, [(3, 'expected 3 fields, found 2'), (4, "invalid status 'L'")])`.
