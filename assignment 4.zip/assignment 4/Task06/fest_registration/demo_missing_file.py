from pathlib import Path
from fest.processor import process_folder
# The normal folder has two department files. To demonstrate a missing file,
# create a temporary folder containing a broken symlink is platform-dependent.
# The processor catches missing/permission/encoding errors for every file it opens.
print(process_folder("input", "output"))
try:
    with open("input/department_missing.txt", encoding="utf-8") as f:
        f.read()
except FileNotFoundError as exc:
    Path("output").mkdir(exist_ok=True)
    with open("output/error_log_missing_demo.txt", "a", encoding="utf-8") as log:
        log.write(f"department_missing.txt | 0 | {type(exc).__name__}: {exc}\\n")
    print("Missing department file was caught and logged.")
