from fest import process_folder
if __name__ == "__main__":
    clean, errors = process_folder("input", "output")
    print(f"Processed {len(clean)} valid unique registrations; {len(errors)} issue(s) logged.")
