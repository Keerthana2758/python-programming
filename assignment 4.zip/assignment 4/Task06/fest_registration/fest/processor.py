import csv
from pathlib import Path
from .reader import iter_input_files, read_file
from .validator import validate_line, InvalidRegistration

def process_folder(input_folder, output_folder="output"):
    out = Path(output_folder)
    out.mkdir(parents=True, exist_ok=True)
    seen = set()
    clean = []
    errors = []
    event_map = {}

    for path in iter_input_files(input_folder):
        try:
            for line_no, line in read_file(path):
                if not line.strip():
                    continue
                try:
                    item = validate_line(line)
                    reg = item["register"]
                    if reg in seen:
                        raise InvalidRegistration(f"duplicate register number {reg}")
                    seen.add(reg)
                    clean.append(item)
                    for event in item["events"]:
                        event_map.setdefault(event, []).append(item)
                except InvalidRegistration as exc:
                    errors.append([path.name, line_no, str(exc), line])
        except (FileNotFoundError, PermissionError, UnicodeDecodeError, OSError) as exc:
            errors.append([path.name, 0, f"{type(exc).__name__}: {exc}", ""])

    with (out / "master_list.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Register Number", "Name", "Department", "Email", "Events"])
        for x in clean:
            writer.writerow([x["register"], x["name"], x["department"], x["email"], ";".join(x["events"])])

    for event, people in sorted(event_map.items()):
        safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in event)
        with (out / f"{safe_name}_participants.csv").open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Register Number", "Name", "Department", "Email"])
            for x in people:
                writer.writerow([x["register"], x["name"], x["department"], x["email"]])

    with (out / "summary.txt").open("w", encoding="utf-8") as f:
        f.write(f"Valid unique registrations: {len(clean)}\\n")
        f.write(f"Events: {len(event_map)}\\n")
        for event, people in sorted(event_map.items()):
            f.write(f"{event}: {len(people)} participant(s)\\n")

    with (out / "error_log.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["File", "Line", "Error", "Original line"])
        writer.writerows(errors)

    return clean, errors
