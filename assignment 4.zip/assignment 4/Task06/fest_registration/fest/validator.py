class InvalidRegistration(Exception):
    pass

def validate_line(line):
    fields = [x.strip() for x in line.split(",")]
    if len(fields) != 5:
        raise InvalidRegistration(f"expected 5 comma-separated fields, found {len(fields)}")
    reg, name, department, email, event_text = fields
    if not all((reg, name, department, email, event_text)):
        raise InvalidRegistration("one or more required fields are empty")
    # Basic e-mail validation using string methods (not a full RFC parser).
    if email.count("@") != 1:
        raise InvalidRegistration("email must contain exactly one @")
    local, domain = email.split("@")
    if not local or not domain or "." not in domain or domain.startswith(".") or domain.endswith("."):
        raise InvalidRegistration("email domain/local part is invalid")
    events = [e.strip() for e in event_text.split(";") if e.strip()]
    if not events:
        raise InvalidRegistration("at least one event is required")
    return {"register": reg, "name": name, "department": department,
            "email": email, "events": events}
