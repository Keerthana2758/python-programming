from pathlib import Path

def iter_input_files(folder):
    return sorted(Path(folder).glob("*.txt"))

def read_file(path):
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            yield line_no, line.rstrip("\n")
