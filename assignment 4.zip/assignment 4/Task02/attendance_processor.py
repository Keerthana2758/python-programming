from pathlib import Path
from collections import defaultdict
import csv

def process_month(input_folder, summary_path="attendance_summary.csv",
                  damaged_path="damaged_lines.csv"):
    counts = defaultdict(lambda: {"P": 0, "A": 0})
    damaged = []
    files = sorted(Path(input_folder).glob("*.txt"))

    for path in files:
        try:
            with path.open("r", encoding="utf-8") as source:
                for line_no, raw in enumerate(source, 1):
                    if not raw.strip():
                        continue
                    fields = [x.strip() for x in raw.rstrip("\n").split(",")]
                    if len(fields) != 3 or fields[2] not in ("P", "A"):
                        damaged.append((path.name, line_no, raw.rstrip("\n")))
                        continue
                    register, date, status = fields
                    counts[register][status] += 1
        except (FileNotFoundError, PermissionError, UnicodeDecodeError) as exc:
            damaged.append((path.name, 0, f"FILE ERROR: {exc}"))

    with open(summary_path, "w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out)
        writer.writerow(["Register Number", "Present", "Absent", "Total", "Percentage"])
        for reg, item in sorted(counts.items()):
            total = item["P"] + item["A"]
            pct = (item["P"] / total * 100) if total else 0
            writer.writerow([reg, item["P"], item["A"], total, f"{pct:.2f}"])
    with open(damaged_path, "w", newline="", encoding="utf-8") as out:
        writer = csv.writer(out)
        writer.writerow(["File", "Line Number", "Damaged Line"])
        writer.writerows(damaged)
    return counts, damaged

if __name__ == "__main__":
    process_month("daily_files")
