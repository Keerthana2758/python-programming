Run: `python attendance_processor.py`. Produces attendance_summary.csv and damaged_lines.csv.
