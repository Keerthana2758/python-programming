from attendance import read_records, percentage, absent_three_consecutive, write_percentage, write_absentees
if __name__ == "__main__":
    records = read_records("data")
    write_percentage(percentage(records))
    write_absentees(absent_three_consecutive(records))
