"""Attendance processing package."""
from .reader import read_records
from .stats import percentage, absent_three_consecutive
from .report import write_percentage, write_absentees
