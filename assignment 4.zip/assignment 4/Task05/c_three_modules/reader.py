from pathlib import Path
def read_records(folder):
    rows = []
    for path in sorted(Path(folder).glob("*.txt")):
        with path.open(encoding="utf-8") as f:
            rows.extend(line.strip().split(",") for line in f if line.strip())
    return rows
