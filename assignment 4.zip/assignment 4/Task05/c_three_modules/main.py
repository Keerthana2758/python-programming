from reader import read_records
from stats import percentage, absent_three_consecutive
from report import write_percentage, write_absentees
if __name__ == "__main__":
    rows = read_records("data")
    write_percentage(percentage(rows))
    write_absentees(absent_three_consecutive(rows))
