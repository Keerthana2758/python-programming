def write_percentage(data, path="percentage.txt"):
    with open(path, "w", encoding="utf-8") as f:
        for r, p in sorted(data.items()): f.write(f"{r},{p:.2f}%\n")
def write_absentees(data, path="three_day_absentees.txt"):
    with open(path, "w", encoding="utf-8") as f:
        for r in data: f.write(r + "\n")
