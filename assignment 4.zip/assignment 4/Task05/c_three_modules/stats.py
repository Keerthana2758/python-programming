def percentage(rows):
    counts = {}
    for reg, date, status in rows:
        counts.setdefault(reg, [0, 0]); counts[reg][0 if status == "P" else 1] += 1
    return {r: p/(p+a)*100 for r, (p, a) in counts.items() if p+a}
def absent_three_consecutive(rows):
    data = {}
    for r, d, s in rows: data.setdefault(r, {})[d] = s
    result = []
    for r, days in data.items():
        dates = sorted(days)
        if any(all(days[x] == "A" for x in dates[i:i+3]) for i in range(len(dates)-2)):
            result.append(r)
    return result
