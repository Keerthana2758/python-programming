import attendance_utils
if __name__ == "__main__":
    rows = attendance_utils.read_records("data")
    attendance_utils.write_reports(rows)
