from pathlib import Path
def read_records(folder):
    rows = []
    for path in sorted(Path(folder).glob("*.txt")):
        with path.open(encoding="utf-8") as f:
            rows.extend(line.strip().split(",") for line in f if line.strip())
    return rows
def write_reports(rows):
    counts, dates = {}, {}
    for reg, date, status in rows:
        counts.setdefault(reg, [0, 0]); counts[reg][0 if status == "P" else 1] += 1
        dates.setdefault(reg, {})[date] = status
    with open("percentage.txt", "w", encoding="utf-8") as out:
        for reg, (p, a) in sorted(counts.items()):
            out.write(f"{reg},{p/(p+a)*100:.2f}%\n")
    with open("three_day_absentees.txt", "w", encoding="utf-8") as out:
        for reg, ds in dates.items():
            ordered = sorted(ds)
            if any(all(ds[d] == "A" for d in ordered[i:i+3]) for i in range(len(ordered)-2)):
                out.write(reg + "\n")
