from pathlib import Path
def read_records(folder):
    records = []
    for path in sorted(Path(folder).glob("*.txt")):
        with path.open(encoding="utf-8") as f:
            records.extend(line.strip().split(",") for line in f if line.strip())
    return records
def percentage(records):
    counts = {}
    for reg, date, status in records:
        counts.setdefault(reg, [0, 0])
        counts[reg][0 if status == "P" else 1] += 1
    return {reg: (p / (p + a) * 100) for reg, (p, a) in counts.items() if p + a}
def write_report(data, filename="percentage.txt"):
    with open(filename, "w", encoding="utf-8") as f:
        for reg, pct in sorted(data.items()):
            f.write(f"{reg},{pct:.2f}%\n")
def absent_three_consecutive(records):
    by_student = {}
    for reg, date, status in records:
        by_student.setdefault(reg, {})[date] = status
    result = []
    for reg, days in by_student.items():
        dates = sorted(days)
        for i in range(len(dates) - 2):
            if all(days[d] == "A" for d in dates[i:i+3]):
                result.append(reg); break
    return result
if __name__ == "__main__":
    rows = read_records("data")
    stats = percentage(rows)
    write_report(stats)
    Path("three_day_absentees.txt").write_text("\n".join(absent_three_consecutive(rows)), encoding="utf-8")
