# Assignment 4 – Python Programming (CSA08), CO4

**Student:** ____________________  
**Register Number:** ____________________  
**Python version:** Python 3.10+ (developed using standard-library features)  
**Libraries:** Python standard library only (`pathlib`, `decimal`, `csv`, `collections`, `tempfile`, `os`, `datetime`).

## Repository setup
Create a GitHub repository named `CSA08-<RegisterNumber>-Assignment4`, upload this folder, and add the faculty as collaborator if private. Add the repository URL to `Assignment_Report.md`.

## Run commands
- Task 1: `cd Task01 && python task1_repaired.py`
- Task 2: `cd Task02 && python attendance_processor.py`
- Task 3: `cd Task03 && python complete_code.py`
- Task 4: `cd Task04 && python returns_processor.py`
- Task 5: run `python main.py` in `Task05/b_module`, `Task05/c_three_modules`, or `Task05/d_package`; run `python attendance_all.py` in `Task05/a_single_script` (create a `data/` directory there and copy sample data from `Task05/data/`).
- Task 6: `cd Task06/fest_registration && python main.py`; missing-file demonstration: `python demo_missing_file.py`

## Results
Task 1 calculates totals with Decimal and records rejected lines. Task 2 produces attendance percentage and damaged-line reports. Task 3 completes the required custom-exception program and prints the expected tuple. Task 4 appends daily returned books and logs file errors. Task 5 provides four code organisations. Task 6 creates the clean fest master list, event-wise lists, summary and error log.

## Dependencies
No third-party packages are required. See `requirements.txt`.
