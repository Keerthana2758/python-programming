from decimal import Decimal, InvalidOperation
from pathlib import Path

def total_mess_bills(filename):
    total = Decimal("0.00")
    report_lines = []
    rejected = []

    try:
        with open(filename, "r", encoding="utf-8") as file:
            for line_number, line in enumerate(file, start=1):
                if not line.strip():
                    continue
                parts = [part.strip() for part in line.rstrip("\n").split(",")]
                try:
                    if len(parts) != 3:
                        raise ValueError(f"expected 3 fields, found {len(parts)}")
                    register, name, amount_text = parts
                    amount = Decimal(amount_text)
                    if not amount.is_finite():
                        raise InvalidOperation
                    total += amount
                    report_lines.append(f"{name}: {amount:.2f}")
                except (ValueError, InvalidOperation) as exc:
                    rejected.append((line_number, line.rstrip("\n"), str(exc)))
    except (FileNotFoundError, PermissionError, UnicodeDecodeError) as exc:
        print(f"Could not process {filename}: {exc}")
        return None, [], [(0, "", str(exc))]

    print("\n".join(report_lines))
    print(f"Total {total:.2f}")
    if rejected:
        print("Rejected records:")
        for item in rejected:
            print(item)
    return total, report_lines, rejected

if __name__ == "__main__":
    total_mess_bills("mess_oct.txt")
