Run: `python task1_repaired.py` from this folder. Uses Decimal for currency and records rejected lines.
