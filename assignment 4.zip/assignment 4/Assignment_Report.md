# Python Programming – Assignment 4 (CO4)
**Course:** Python Programming (CSA08)  
**Student Name:** ____________________  
**Register Number:** ____________________  
**Submission Date:** 15/11/2026  
**GitHub Repository:** Add your repository URL here.

## Task 1 – File-processing design review

### 1.1 Diagnosis
1. Hard-coded absolute path: the script fails on another computer or when the office moves the file.
2. File is not closed: resources remain occupied; buffered data may not be safely flushed after later modifications.
3. `read()` loads the entire file: memory use grows with file size and may be excessive for 50,000 or more records.
4. Bare `except: pass`: hides programming errors and damaged records; staff cannot identify missing totals.
5. `int()` rejects decimal amounts such as 1250.50, so valid bills are silently omitted.
6. `split(",")` is not checked for exactly three fields; malformed records may cause indexing errors.
7. Repeated string concatenation creates unnecessary temporary strings and becomes inefficient for large reports.
8. A trailing blank line is treated as a record and triggers an exception that is silently ignored.
9. Rejected records are not logged, so the office cannot correct source data or audit totals.

### 1.2 Repaired design
The executable solution is `Task01/task1_repaired.py`. It accepts a filename parameter, uses `with`, iterates line by line, uses `Decimal` for money, catches specific conversion/format errors and records rejected lines with their line numbers.

### 1.3 Design defence (under 100 words)
The repaired program uses constant-sized input buffering because it processes one line at a time. The `with` statement closes the file even if an error occurs. `Decimal` preserves paise accurately, while specific exceptions prevent unrelated programming errors from being hidden. Invalid records are retained in a rejection list for correction and audit. A list followed by `join` avoids repeated immutable-string concatenation. Thus, the program is more reliable and uses memory proportional to one line plus the report/rejection data, rather than loading the complete input file.

**Alternative and complexity:** Both approaches take O(n) time for n characters/records. `read()` or `readlines()` requires O(file size) input memory. Iterating line by line requires O(maximum line length) input memory; report and rejected-record storage add their own output-dependent memory. If the report is streamed directly to an output file, total auxiliary memory can remain O(one line).

## Task 2 – Biometric attendance files

### 2.1 Data model
Each daily UTF-8 text file contains one record per line: `register_number,YYYY-MM-DD,P` or `register_number,YYYY-MM-DD,A`. A dictionary maps each register number to a pair of counters `{P: present_count, A: absent_count}`. A list stores damaged records as `(filename, line_number, original_line)`. `attendance_summary.csv` contains register number, present, absent, total and percentage. `damaged_lines.csv` contains filename, line number and original damaged line.

### 2.2 File operations
Open daily inputs with mode `r` and UTF-8 encoding. Iterate over the file object to process one line at a time; this is preferable to `read()` for large files. Open reports with mode `w` to create fresh monthly reports. Use `csv.writer`/`write` to produce correctly separated output. Append mode `a` would be suitable for a persistent audit log that must retain previous runs, but the monthly report is regenerated.

### 2.3 Pseudocode (SIMATS-style)
```
ALGORITHM MonthlyAttendance
INPUT: folder containing daily attendance text files
OUTPUT: attendance_summary.csv, damaged_lines.csv
BEGIN
    CREATE empty dictionary Counts
    CREATE empty list Damaged
    Files ← SORTED list of *.txt files in folder
    FOR EACH File IN Files DO
        TRY
            OPEN File in read mode with UTF-8 encoding
            LineNumber ← 0
            FOR EACH Line IN File DO
                LineNumber ← LineNumber + 1
                IF Line is blank THEN
                    CONTINUE
                END IF
                Fields ← split Line by comma and trim spaces
                IF number of Fields is not 3 OR status is not P or A THEN
                    ADD (File, LineNumber, Line) to Damaged
                ELSE
                    Reg ← Fields[1]
                    IF Reg is not in Counts THEN
                        Counts[Reg] ← (0, 0)
                    END IF
                    INCREMENT present or absent counter according to status
                END IF
            END FOR
            CLOSE File
        CATCH file access or decoding error
            ADD file error information to Damaged
        END TRY
    END FOR
    WRITE one summary row for every register number in Counts
    WRITE every item in Damaged to damaged_lines.csv
END
```

### 2.4 Trace
Input:
```
R01,2026-10-01,P
R02,2026-10-01,A
damaged
```
After line 1: `R01 → P=1,A=0`. After line 2: `R02 → P=0,A=1`. Line 3 has one field, so it is added to damaged records with line number 3. Percentages: R01 = 100%; R02 = 0%.

**Alternative and complexity:** Re-reading every file for every student takes O(s·f·l) time for s students, f files and l lines per file. One pass with a dictionary takes O(f·l) time on average, assuming constant-time dictionary operations. The re-reading approach uses O(1) or small working memory per student; the dictionary approach uses O(s) memory for counters plus damaged records.

## Task 3 – Exception handling

### 3.1 Failure table
| Failure | Likely exception | Handling |
|---|---|---|
| Folder does not exist / no matching input | `FileNotFoundError` or empty file list | Report missing input folder |
| Individual file missing | `FileNotFoundError` | Log file name and continue |
| Permission denied | `PermissionError` | Log and continue |
| Invalid UTF-8 bytes | `UnicodeDecodeError` | Log decoding failure |
| Wrong number of fields | Custom `InvalidRecord` (or `ValueError`) | Reject line |
| Invalid status | Custom `InvalidRecord` | Reject line |
| Accessing missing list field without validation | `IndexError` | Prevent by checking field count |
| Empty file | No exception; zero records | Return zero counts and empty error list |
| Invalid numeric conversion, if applicable | `ValueError` | Reject invalid value |

### 3.2 Custom exception
`InvalidRecord` is raised inside `parse_line` when a record does not contain exactly three fields or its status is not P/A. It is caught inside `summarise` around each line, allowing later lines to be processed.

### 3.3 Complete try statement
`Task03/complete_code.py` demonstrates `try`, specific `except` clauses, `else` for successful completion and `finally` for cleanup-related logic. `raise ... from ...` preserves the original cause when a file-level exception is given context. The `with` statement closes the file automatically.

### 3.4 Misuse experiment
Replacing the specific handlers with `except Exception: pass` hides the error. For example, changing `status` to misspelled `statsu` raises `NameError`, but the broad handler catches it and silently continues. The final counts become incomplete and there is no diagnostic message. This is dangerous because a programming defect looks like valid input with fewer records.

**Complete-code expected output:**
```
(1, 1, [(3, 'expected 3 fields, found 2'), (4, "invalid status 'L'")])
```
Changing the filename to a nonexistent path raises a contextual `FileNotFoundError` from `summarise`; the caller should catch it and display/log the message.

**Alternative and complexity:** Exception-based parsing and validation both take O(1) work per line for a fixed number of fields, hence O(n) for n lines. When invalid lines are rare, exceptions are convenient and the exceptional path is seldom used. When invalid lines are common, explicit `if` checks avoid exception construction and traceback overhead and are generally faster. Both use O(1) extra memory per line, excluding stored errors.

## Task 4 – File and exception forensics

### 4.1 Defects
Opening `returns.log` with `w` truncates the file every day, so only the last day's books remain. `write(b)` adds no newline, joining all book names together. If `write()` fails before `close()`, the close statement is skipped and the file may remain open until garbage collection/process exit; buffered output may be lost.

### 4.2 Evidence test
The files `day1.txt`, `day2.txt`, and `day3.txt` are sample inputs. The original defective program can be tested by calling `process` for all three; the final log contains only the third day's text, with entries concatenated. The repaired test is `Task04/returns_processor.py`.

### 4.3 Repair
The repaired version opens the log in append mode, writes one book per line, uses `with` for both input and output and records file/encoding/OS errors in `errors.log`.

### 4.4 Prevention rules
1. Use `with open(...)` so files close reliably on success or failure.
2. Choose mode deliberately: `a` to preserve a running log, `w` only when replacing a report; explicitly write line separators.

**Alternative and complexity:** Manual `try/finally` can open a file, perform writes in `try`, and close it in `finally`. Both approaches have O(n) time and O(1) extra space for n book names if streamed. A correctly written `try/finally` closes the file just like `with`; without cleanup, an error can leave one file open. The `with` version closes deterministically and is shorter/less error-prone.

## Task 5 – Modules and packages

Four executable structures are provided under `Task05/`:
- (a) `a_single_script/attendance_all.py`: all reading, statistics and reporting in one file.
- (b) `b_module/attendance_utils.py` imported by `main.py`.
- (c) `c_three_modules/reader.py`, `stats.py`, `report.py`, coordinated by `main.py`.
- (d) `d_package/attendance/` with `__init__.py`, `reader.py`, `stats.py`, `report.py`, coordinated by `main.py`.

The `if __name__ == "__main__":` guard prevents the main workflow from running merely because a module is imported.

### Requirement change and files changed
- Single script: one file changes.
- One utility module: utility module changes; main may remain unchanged if its public function already writes both reports.
- Three modules: statistics and report modules change; main changes only if new functions are not included in the existing workflow (typically 2–3 files).
- Package: stats and report modules change and package exports/main wiring may change (typically 2–3 files).

### Comparison
| Organisation | Readability | Reuse | Testing | Naming conflicts |
|---|---|---|---|---|
| One script | Easy initially, crowded later | Low | Hard to isolate | More likely |
| One module + main | Better separation | Moderate | Test utility functions | Moderate |
| Three modules | Clear responsibilities | High | Test each module | Lower with clear names |
| Package | Best for growth | Very high | Independent module tests | Lowest with package-qualified names |

`import attendance.stats` imports the module; refer to `attendance.stats.percentage`. `from attendance import stats` imports the submodule name into the current namespace; refer to `stats.percentage`. `from attendance.stats import percentage` imports the function directly; call `percentage(...)`, but the name may collide with another imported function.

**Alternative and complexity:** A single script has no package import overhead and all functions are in one namespace. A package incurs a one-time import/load cost for modules actually imported; Python caches loaded modules in `sys.modules`, so repeated imports normally reuse them. Runtime algorithmic complexity is unchanged. Package memory is O(total imported module code/objects), usually small relative to data. Finding and changing a function is easiest in a single tiny script, but becomes difficult as it grows; clear modules/packages reduce search and change effort.

## Task 6 – College fest registration design challenge

### Stage 1: Inputs, outputs and testable rules
Inputs: five department `.txt` files; one registration per line in the format `register_number,name,department,email,event1;event2`. Outputs: `master_list.csv`, one CSV per event, `summary.txt`, and `error_log.csv`.
Rules:
1. A valid line has exactly five non-empty fields.
2. Email has exactly one `@`, non-empty local/domain portions and a dot in the domain.
3. Events are split on semicolons and at least one event is required.
4. Only the first valid registration for a register number is accepted; later duplicates are logged.
5. Invalid records are logged with filename and line number; processing continues.
6. Missing/unreadable files are logged and do not terminate processing.
7. Every accepted registration appears in the master list and in each selected event file.

### Stage 2: Processing flow
```
START
  |
Find department files
  |
Open each file (file-level try/except)
  |
Read line + line number
  |
Validate field count, required fields, email and events
  | invalid
  +--------------------> Write error log; continue
  |
Check register number in seen set
  | duplicate
  +--------------------> Write duplicate error; continue
  |
Add register number to set
  |
Add record to master list and event dictionary
  |
Write master CSV, event CSVs, summary and error log
  |
END
```

### Stage 3: Critical decisions
Duplicates are detected using a set of register numbers, giving average O(1) membership checks. Email validation uses `count("@")`, `split("@")`, `startswith`, `endswith` and `"." in domain`. `InvalidRegistration` handles record-level failures; `FileNotFoundError`, `PermissionError`, `UnicodeDecodeError` and `OSError` handle file-level failures. A bad line is logged and the next line is processed.

### Stage 4: Package design
`fest/reader.py` lists and reads files; `fest/validator.py` validates a line and defines `InvalidRegistration`; `fest/processor.py` coordinates duplicate detection, event grouping and output writing; `fest/__init__.py` exposes `process_folder`.

Pseudocode:
```
ALGORITHM ProcessFestFiles
INPUT: input folder; OUTPUT: master, event lists, summary, error log
BEGIN
    CREATE empty Seen set, Master list, EventMap dictionary, Errors list
    FOR EACH department file DO
        TRY to open file as UTF-8
            FOR EACH line with line number DO
                TRY
                    Record ← VALIDATE line
                    IF Record.register is in Seen THEN
                        RAISE InvalidRegistration("duplicate")
                    END IF
                    ADD register to Seen
                    ADD Record to Master
                    FOR EACH event in Record.events DO
                        ADD Record to EventMap[event]
                    END FOR
                CATCH InvalidRegistration
                    ADD file, line number and reason to Errors
                END TRY
            END FOR
        CATCH file access or decoding error
            ADD file error to Errors
        END TRY
    END FOR
    WRITE Master as CSV
    FOR EACH event in EventMap DO
        WRITE its participant CSV
    END FOR
    WRITE summary and Errors
END
```

### Stage 5: Implementation and demonstration
Run `python main.py` inside `Task06/fest_registration`. The sample files demonstrate valid registrations, a duplicate R1001, an invalid email, and a damaged line. The program creates the clean master list, event-wise lists, summary and error log. Run `python demo_missing_file.py` to demonstrate catching and logging a missing department file. The implementation continues after record-level and file-level errors.

**Alternative and complexity:** Searching a list of all previously accepted register numbers takes O(n) per registration, producing O(n²) total time in the worst case. A set gives average O(1) membership and O(n) total time. Both use O(n) memory to store accepted register numbers; the set has additional hashing overhead but is substantially faster for large input sets.

## Execution and submission checklist
- Run every `.py` file in the relevant task folder.
- Check generated CSV/TXT outputs and retain screenshots of your own executions.
- Create a GitHub repository named `CSA08-<RegisterNumber>-Assignment4`.
- Add your name, register number and Python version to `README.md`.
- Commit progressively, at least once per task.
- Add the working GitHub URL to this report and the cover page before submission.
